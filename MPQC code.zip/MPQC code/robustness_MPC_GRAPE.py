# -*- coding: utf-8 -*-
"""
Created on Mon Aug 18 11:45:41 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
MPC robustness to model-plant mismatch (single qubit).
- Nominal MPC model for optimization (H0 = omega * SZ).
- Feedback state update uses plant H0 = (omega + eps) * SZ.
- Sweeps eps over a user-defined list and plots final fidelity vs eps.
"""

import numpy as np
import casadi as ca
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import basis, fidelity, Qobj
import time

# ========================= Time & MPC parameters ========================= #
t_end = 2.0
T = 40
dt = t_end / T
full_tlist = np.linspace(0.0, t_end, T+1)

L = 3         # prediction horizon
m = 1         # apply steps per MPC iteration
nb_opts = int(np.ceil(T / m))

# ============================ System parameters ========================= #
nb_inputs = 2
omega = 1.0
ampl0 = [0.2, 0.2]

# Pauli matrices as np arrays for CASADI
SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)

# Pauli matrices as quantum objects for Qutip
H0_nom = omega * Qobj(SX)
Hcs = [Qobj(SZ), Qobj(SY)]


H0_nominal = omega * SX
H_controls = [SZ, SY]

# Initial & target states
psi0 = basis(2, 0)
psi_ref = basis(2, 1)

# ==================== Real-valued state representation =================== #
def psi_to_real_vec(psi_qobj):
    psi = np.asarray(psi_qobj.full()).reshape(-1)
    a = np.real(psi)
    b = np.imag(psi)
    return np.concatenate([a, b]).astype(float)

x0_np = psi_to_real_vec(psi0)
xref_np = psi_to_real_vec(psi_ref)

# Precompute Hr/Hi for nominal H0, H1, H2
H_list = [H0_nominal] + H_controls
H_real = [np.real(H).astype(float) for H in H_list]
H_imag = [np.imag(H).astype(float) for H in H_list]

# ====================== CasADi symbolic model (RK4) ====================== #
x = ca.MX.sym('x', 4)
u = ca.MX.sym('u', nb_inputs)

Hr = ca.DM(H_real[0]) + u[0]*ca.DM(H_real[1]) + u[1]*ca.DM(H_real[2])
Hi = ca.DM(H_imag[0]) + u[0]*ca.DM(H_imag[1]) + u[1]*ca.DM(H_imag[2])

a_vec = x[0:2]
b_vec = x[2:4]
f_a = Hr @ b_vec + Hi @ a_vec
f_b = -Hr @ a_vec + Hi @ b_vec
xdot = ca.vertcat(f_a, f_b)
xdot_fun = ca.Function('xdot_fun', [x, u], [xdot])

def _rk4(xk, uk, h, xdot_fun_local):
    k1 = xdot_fun_local(xk, uk)
    k2 = xdot_fun_local(xk + 0.5*h*k1, uk)
    k3 = xdot_fun_local(xk + 0.5*h*k2, uk)
    k4 = xdot_fun_local(xk + h*k3, uk)
    return xk + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)

# Nominal step function (used inside MPC optimization rollout)
step_fun_nominal = ca.Function('step_fun', [x, u], [_rk4(x, u, dt, xdot_fun)])

# Build drifted plant step function (used only for feedback update)
def build_step_fun_with_drift(eps):
    H0_eps = (omega + eps) * SZ
    H_list_eps = [H0_eps] + H_controls
    H_real_eps = [np.real(H).astype(float) for H in H_list_eps]
    H_imag_eps = [np.imag(H).astype(float) for H in H_list_eps]
    x_eps = ca.MX.sym('x', 4)
    u_eps = ca.MX.sym('u', nb_inputs)
    Hr_eps = ca.DM(H_real_eps[0]) + u_eps[0]*ca.DM(H_real_eps[1]) + u_eps[1]*ca.DM(H_real_eps[2])
    Hi_eps = ca.DM(H_imag_eps[0]) + u_eps[0]*ca.DM(H_imag_eps[1]) + u_eps[1]*ca.DM(H_imag_eps[2])
    a_vec_eps = x_eps[0:2]
    b_vec_eps = x_eps[2:4]
    f_a_eps = Hr_eps @ b_vec_eps + Hi_eps @ a_vec_eps
    f_b_eps = -Hr_eps @ a_vec_eps + Hi_eps @ b_vec_eps
    xdot_eps = ca.vertcat(f_a_eps, f_b_eps)
    xdot_fun_eps = ca.Function('xdot_fun_eps', [x_eps, u_eps], [xdot_eps])
    return ca.Function('step_fun_eps', [x_eps, u_eps], [_rk4(x_eps, u_eps, dt, xdot_fun_eps)])

# Fidelity on real-valued vector
ar = ca.DM(xref_np[0:2])
br = ca.DM(xref_np[2:4])
def fidelity_from_x(xv):
    a = xv[0:2]; b = xv[2:4]
    cre = ca.dot(ar, a) + ca.dot(br, b)
    cim = ca.dot(ar, b) - ca.dot(br, a)
    return cre*cre + cim*cim

# =========================== MPC settings =============================== #
lambda_u = 1e-4
u_ref = np.array([0.0, 0.0], dtype=float)  # keep simple reference on inputs
u_ref_dm = ca.DM(u_ref)

nlp_opts = {
    'ipopt.print_level': 0,
    'ipopt.max_iter': 150,
    'ipopt.tol': 1e-6,
    'ipopt.linear_solver': 'mumps',
    'print_time': 0
}

# =========================== Helpers / Runners =========================== #
def run_mpc_for_eps(eps_plant, verbose=False):
    """
    Run the MPC loop once with plant drift 'eps_plant'.
    Returns:
        controls: (nb_inputs, T)
        fidelities: list length T
        final_fid: float
    """
    mpc_control = np.zeros((nb_inputs, T), dtype=float)
    current_x = x0_np.copy()
    U_prev_window = None
    step_fun_eps = build_step_fun_with_drift(eps_plant)

    start_total = time.time()

    for step_idx in range(nb_opts):
        t_idx = step_idx * m
        if t_idx >= T:
            break

        window_end = min(t_idx + L, T)
        N = window_end - t_idx
        apply_steps = min(m, N)

        # Decision variables for this window
        U = ca.MX.sym('U', nb_inputs, N)

        # Single-shoot on NOMINAL model (optimization model)
        xk = ca.DM(current_x)
        J = 0
        for k in range(N):
            uk = U[:, k]
            J += lambda_u * ca.sumsqr(uk - u_ref_dm)
            xk = step_fun_nominal(xk, uk)
            J += (1.0 - fidelity_from_x(xk))

        # Terminal fidelity equality (drive to target)
        g = 1.0 - fidelity_from_x(xk)
        lbg = np.zeros(g.shape[0])
        ubg = np.zeros(g.shape[0])

        nlp = {'x': ca.vec(U), 'f': J, 'g': g}
        solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

        # Bounds on inputs
        lbw = np.full(nb_inputs*N, -1.0)
        ubw = np.full(nb_inputs*N, 1.0)

        # Initial guess
        if U_prev_window is None:
            guess = np.zeros((nb_inputs, N), dtype=float)
            for i in range(nb_inputs):
                guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, N))
        else:
            guess = np.zeros((nb_inputs, N), dtype=float)
            for i in range(nb_inputs):
                tail = U_prev_window[i, apply_steps:]
                n_fill = min(tail.shape[0], N)
                guess[i, :n_fill] = tail[:n_fill]

        x0_guess = ca.vec(ca.DM(guess)).full()

        sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw)
        U_opt = np.array(sol['x']).reshape((nb_inputs, N), order='F')

        # Apply first m controls and update PLANT state with drifted step function
        for i in range(nb_inputs):
            mpc_control[i, t_idx:t_idx+apply_steps] = U_opt[i, :apply_steps]

        for local in range(apply_steps):
            uk = ca.DM(mpc_control[:, t_idx + local])
            current_x = np.array(step_fun_eps(ca.DM(current_x), uk)).reshape(-1)

        U_prev_window = U_opt.copy()

    end_total = time.time()
    if verbose:
        print(f"[eps={eps_plant:+.4f}] MPC runtime: {end_total - start_total:.2f} s")

    # Final trajectory simulation (using PLANT drift)
    state = psi0
    fidelities = []
    #fidelities.append(float(fidelity(state, psi_ref)))
    for t in range(T):
        fidelities.append(float(fidelity(state, psi_ref)))
        H = (omega + eps_plant) * SZ
        for i in range(nb_inputs):
            H = H + mpc_control[i, t] * H_controls[i]
        U_step = expm(-1j * H * dt)
        vec = (U_step @ state.full()).reshape((2, 1))
        state = Qobj(vec, dims=[[2], [1]])
    
    fidelities.append(float(fidelity(state, psi_ref)))
        
    return mpc_control, fidelities, float(fidelities[-1])

def evaluate_controls_on_plant(controls, eps):
    """
    Apply a given control sequence (shape (nb_inputs, T)) to a plant with drift eps.
    Returns final fidelity.
    """
    state = psi0
    for t in range(T):
        H = (omega + eps) * SZ
        for i in range(nb_inputs):
            H = H + controls[i, t] * H_controls[i]
        U_step = expm(-1j * H * dt)
        vec = (U_step @ state.full()).reshape((2, 1))
        state = Qobj(vec, dims=[[2], [1]])
    return float(fidelity(state, psi_ref))

# ================================ Sweep ================================= #
if __name__ == "__main__":
    # Choose eps drift values to test (both positive and negative)
    eps_list = np.linspace(-1, 1, 41)
    final_fids_mpc = []
    fid_traces_sample = {}   # store a few traces to visualize time evolution

    # Run MPC for each eps
    for idx, eps in enumerate(eps_list):
        controls, fids, f_final = run_mpc_for_eps(eps, verbose=True)
        final_fids_mpc.append(f_final)
        # keep a few traces to visualize (e.g., first, middle, last)
        fid_traces_sample[eps] = (fids, controls)

    

    # ===================== Hook for GRAPE comparison ===================== #
    # ===== GRAPE Parameters =====
    max_iter = 300
    learning_rate = 0.1
    alpha = 0.0  # control penalty
    eps_plant = 0.2  # mismatch, same as in MPC
    
    # Fidelity
    def fidelity(psi, psi_target):
        return np.abs((psi_target.dag() * psi)[0, 0])**2
    
    def forward(psi0, u, H0, Hcs, dt, N):
        psi_list = [psi0]
        psi = psi0
        for j in range(N):
            H = H0 + sum(u[k, j] * Hcs[k] for k in range(len(Hcs)))
            U = (-1j * H * dt).expm()
            psi = (U * psi).unit()
            psi_list.append(psi)
        return psi_list
    
    def backward(psi_target, u, H0, Hcs, dt, N):
        lam = psi_target
        lam_list = [None] * (N + 1)
        lam_list[N] = lam
        for j in reversed(range(N)):
            H = H0 + sum(u[k, j] * Hcs[k] for k in range(len(Hcs)))
            Udag = (-1j * H * dt).expm().dag()
            lam = (Udag * lam).unit()
            
            lam_list[j] = lam
        return lam_list
    
    def grape_optimize(psi0, psi_target, H0, Hcs, dt, N, initial_guess,
                       max_iter=100, learning_rate=0.1, alpha=0.0):
        u = initial_guess.copy()
        fidelity_log = []
        
        for it in range(max_iter):
            psi_list = forward(psi0, u, H0, Hcs, dt, N)
            psi_final = psi_list[-1]
            F = fidelity(psi_final, psi_target)
            fidelity_log.append(F)
    
            if (1 - F) < 1e-6:
                print(f"Converged at iteration {it}")
                break
    
            lam_list = backward(psi_target, u, H0, Hcs, dt, N)
    
            grad = np.zeros_like(u)
            for j in range(N):
                for k in range(len(Hcs)):
                    grad[k, j] = 2 * np.imag((lam_list[j+1].dag() * Hcs[k] * psi_list[j])[0, 0])
                    grad[k, j] += 2 * alpha * (u[k, j])  # optional regularization
            grad -= 0.1 * u  # L2 regularization
    
            u += learning_rate * grad
            u = np.clip(u, -1.0, 1.0)
            
        return u, fidelity_log
    
    # ===== Run GRAPE Optimization (Nominal Model) =====
    initial_guess = np.zeros((nb_inputs, T))
    start_time = time.time()
    u_opt, fidelity_log = grape_optimize(psi0, psi_ref, H0_nom, Hcs, dt, T,
                                         initial_guess, max_iter, learning_rate, alpha)
    end_time = time.time()
    
    print(f"GRAPE optimization completed in {end_time - start_time:.2f} seconds")
    print(f"Final Fidelity (nominal model): {fidelity_log[-1]:.6f}")
    
   # ===== Evaluate Optimized Controls on Plant with Drift (store trajectories) =====
    final_fids_GRAPE = []
    fid_traces_GRAPE = {}  # store trajectories for plotting

    for idx, eps in enumerate(eps_list):
        if eps == 0.0:
            H0_plant = omega * SX   # must match the nominal model
        else:
            H0_plant = (omega + eps) * SZ
        psi_list_plant = forward(psi0, u_opt, H0_plant, Hcs, dt, T)
        
        fidelities_plant = [fidelity(psi, psi_ref) for psi in psi_list_plant]
        final_fids_GRAPE.append(fidelities_plant[-1])
        
        # store a few representative traces, e.g., first, middle, last
        #if idx == 0 or idx == len(eps_list)//2 or idx == len(eps_list)-1:
        fid_traces_GRAPE[eps] = fidelities_plant
    
        print(f"Final Fidelity on drifted plant for eps = {eps:.6f} is : {fidelities_plant[-1]:.6f}")
    
            
            
 






light_blue = (0.2, 0.4, 0.7)  # light blue color for drifted trajectories

fig = plt.figure(figsize=(14, 16))  # bigger figure
gs = fig.add_gridspec(2, 2, height_ratios=[1, 1.2], hspace=0.35, wspace=0.3)

tick_labelsize = 18  # larger ticks

# ------------------ Subplot 1: MPC fidelity trajectories ------------------ #
ax0 = fig.add_subplot(gs[0, 0])
blue_label_added = False
for eps, (fids, _) in fid_traces_sample.items():
    if eps == 0.0:  # nominal
        ax0.plot(full_tlist, fids, color='red', label='Nominal', linewidth=4)
    else:           # drifted
        if not blue_label_added:
            ax0.plot(full_tlist, fids, color=light_blue, alpha=0.7,
                     label=r'Drift error $\epsilon \in [-1,1]$')
            blue_label_added = True
        else:
            ax0.plot(full_tlist, fids, color=light_blue, alpha=0.7)
ax0.set_xlabel('time t', size=22)
ax0.set_ylabel('Fidelity', size=22)
ax0.set_title('Basic MPQC', size=22, loc='left')
ax0.set_ylim(0.0, 1.1)
ax0.grid(True, linestyle='--')
ax0.legend(fontsize=16)
ax0.tick_params(axis='both', labelsize=tick_labelsize)

# ------------------ Subplot 2: GRAPE fidelity trajectories ------------------ #
ax1 = fig.add_subplot(gs[0, 1])
blue_label_added = False
for eps, fids in fid_traces_GRAPE.items():
    if eps == 0.0:
        ax1.plot(full_tlist, fids, color='red', label='Nominal', linewidth=4)
    else:
        if not blue_label_added:
            ax1.plot(full_tlist, fids, color=light_blue, alpha=0.7,
                     label=r'Drift error $\epsilon \in [-1,1]$')
            blue_label_added = True
        else:
            ax1.plot(full_tlist, fids, color=light_blue, alpha=0.7)
ax1.set_xlabel('time t', size=22)
ax1.set_ylabel('Fidelity', size=22)
ax1.set_title('QOC with GRAPE', size=22, loc='left')
ax1.set_ylim(0.0, 1.1)
ax1.grid(True, linestyle='--')
ax1.legend(fontsize=16)
ax1.tick_params(axis='both', labelsize=tick_labelsize)

# ------------------ Subplot 3: Final fidelities (span both columns) ------------------ #
ax2 = fig.add_subplot(gs[1, :])  # spans both columns
ax2.plot(eps_list, final_fids_mpc, color='green', marker='o', markersize=8, linewidth=3, label='MPQC (feedback)')
ax2.plot(eps_list, final_fids_GRAPE, color='orange', marker='o', markersize=8, linewidth=3, label='GRAPE (open loop)')
ax2.set_title(r'Fidelity of $\psi(t_end)$', size=22, loc='left')
ax2.set_xlabel(r'Drift error $\epsilon$', size=22)
ax2.set_ylabel('Final Fidelity', size=22)
ax2.set_ylim(0.0, 1.1)
ax2.grid(True, linestyle='--')
ax2.legend(fontsize=16)
ax2.tick_params(axis='both', labelsize=tick_labelsize)

plt.tight_layout()
plt.show()





# light_blue = (0.2, 0.4, 0.7)  # light blue color for drifted trajectories

# fig, axs = plt.subplots(2, 2, figsize=(12, 8))

# # ------------------ Subplot 1: MPC fidelity trajectories ------------------ #
# ax = axs[0, 0]
# blue_label_added = False
# for eps, (fids, _) in fid_traces_sample.items():
#     if eps == 0.0:  # nominal
#         ax.plot(full_tlist, fids, color='red', label='Nominal', linewidth=2)
#     else:           # drifted
#         if not blue_label_added:
#             ax.plot(full_tlist, fids, color=light_blue, alpha=0.7, label=r'Drift error $\epsilon \in [-1,1]$')
#             blue_label_added = True
#         else:
#             ax.plot(full_tlist, fids, color=light_blue, alpha=0.7)
# ax.set_xlabel('t [ns]', size = 16)
# ax.set_ylabel('Fidelity', size = 16)
# ax.set_title('MPC Fidelity Trajectories', size = 18)
# ax.set_ylim(0.0, 1.1)
# ax.grid(True, linestyle='--')
# ax.legend()

# # ------------------ Subplot 2: GRAPE fidelity trajectories ------------------ #
# ax = axs[0, 1]
# blue_label_added = False
# for eps, fids in fid_traces_GRAPE.items():
#     if eps == 0.0:
#         ax.plot(full_tlist, fids, color='red', label='Nominal', linewidth=2)
#     else:
#         if not blue_label_added:
#             ax.plot(full_tlist, fids, color=light_blue, alpha=0.7, label=r'Drift error $\epsilon \in [-1,1]$')
#             blue_label_added = True
#         else:
#             ax.plot(full_tlist, fids, color=light_blue, alpha=0.7)
# ax.set_xlabel('t [ns]', size = 16)
# ax.set_ylabel('Fidelity', size = 16)
# ax.set_title('GRAPE Fidelity Trajectories', size = 18)
# ax.set_ylim(0.0, 1.1)
# ax.grid(True, linestyle='--')
# ax.legend()

# # # ------------------ Subplot 3: GRAPE fidelity log ------------------ #
# # ax = axs[1, 0]
# # ax.plot(fidelity_log, label='Training (nominal)', color= 'blue', linewidth=2)
# # ax.set_xlabel('Iteration', size = 16)
# # ax.set_ylabel('Fidelity', size = 16)
# # ax.set_title('GRAPE Training Fidelity', size = 18)
# # ax.grid(True, linestyle='--')
# # ax.legend()

# # ------------------ Subplot 4: Final fidelities ------------------ #
# ax = axs[1, :]
# ax.plot(eps_list, final_fids_mpc, color = 'green', marker='o', label='MPC (feedback)')
# ax.plot(eps_list, final_fids_GRAPE, color = 'orange', marker='o', label='GRAPE (open loop)')
# ax.set_xlabel(r' Drift error $\epsilon$', size = 16)
# ax.set_ylabel('Final Fidelity', size = 16)
# ax.set_title('Final Fidelity vs Drift Error', size = 18)
# ax.set_ylim(0.0, 1.1)
# ax.grid(True, linestyle='--')
# ax.legend()

# plt.tight_layout()
# plt.show()


# # ------------------ Plot2: MPC fidelity trajectories for small eps ------------------ #
# blue_label_added = False
# for eps, (fids, _) in fid_traces_sample.items():
#     if eps == 0.0:  # nominal
#         plt.plot(full_tlist, fids, color='red', label='Nominal', linewidth=2)
#     else:
#         if eps < 0.1: # small drift
#             if not blue_label_added:
#                 plt.plot(full_tlist, fids, color=light_blue, alpha=0.7, label='Drifted eps [-1,1]')
#                 blue_label_added = True
#             else:
#                 plt.plot(full_tlist, fids, color=light_blue, alpha=0.7)
# ax.set_xlabel('Time')
# ax.set_ylabel('Fidelity')
# ax.set_title('MPC Fidelity Trajectories for |eps| <1 ')
# ax.set_ylim(0.0, 1.1)
# ax.grid(True)
# ax.legend()