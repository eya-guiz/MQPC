# -*- coding: utf-8 -*-
"""
MPC with Krotov optimization for 3-control benchmark with bound constraints [-1, 1]
"""

import numpy as np
import matplotlib.pyplot as plt
from qutip import *
import krotov
from time import time

# Standard basis states
ket0 = basis(2, 0)       # |0>
ket1 = basis(2, 1)       # |1>

# Superposition states
ket_plus  = (ket0 + ket1).unit()        # |+>
ket_minus = (ket0 - ket1).unit()        # |->

ket_yplus  = (ket0 + 1j * ket1).unit()  # |y+>
ket_yminus = (ket0 - 1j * ket1).unit()  # |y->



class QuantumMPC_Krotov:
    def __init__(self, omega=1.0, ampl0=[0.2, 0.2, 0.2], T=5.0, N=100, prediction_horizon=20, control_horizon=10):
        """
        Initialize MPC controller for 3-control quantum system with bound constraints
        """
        self.omega = omega
        self.ampl0 = ampl0  # Now a list of 3 amplitudes [u1, u2, u3]
        self.T = T
        self.N = N
        self.tlist = np.linspace(0, T, N)
        self.dt = T / (N - 1)
        
        self.prediction_horizon = prediction_horizon
        self.control_horizon = control_horizon
        
        # System Hamiltonian: H0 = ωσ_z, H1 = σ_x, H2 = σ_y, H3 = σ_z
        self.H0 = -0.5 * omega * sigmaz()  # Drift Hamiltonian
        self.H1 = sigmax()  # Control Hamiltonian 1
        self.H2 = sigmay()  # Control Hamiltonian 2
        self.H3 = sigmaz()  # Control Hamiltonian 3
        
        # Target state (can be changed to any state on Bloch sphere)
        self.initial_state = ket("0")
        self.target_state = ket_yplus  
        
        # Control bounds [-1, 1] for all 3 controls
        self.control_bounds = [-1.0, 1.0]
        
        # Storage for results
        self.mpc_states = []
        self.mpc_controls_1 = []
        self.mpc_controls_2 = []
        self.mpc_controls_3 = []
        self.mpc_fidelities = []
        self.control_times = []
        
    def shape_function(self, t):
        """Shape function for control updates"""
        return krotov.shapes.flattop(t, t_start=0, t_stop=self.T, t_rise=0.3, func="blackman")
    
    def optimize_controls_mpc_step(self, current_state, current_time):
        """
        Optimize controls for one MPC step using Krotov with bound constraints
        """
        t_start = current_time
        t_stop = min(current_time + self.control_horizon * self.dt, self.T)
        opt_tlist = np.linspace(t_start, t_stop, self.control_horizon + 1)
        
        # Initial guess for controls (clipped to bounds)
        initial_guess_1 = np.clip([self.ampl0[0]] * self.control_horizon, 
                                 self.control_bounds[0], self.control_bounds[1])
        initial_guess_2 = np.clip([self.ampl0[1]] * self.control_horizon,
                                 self.control_bounds[0], self.control_bounds[1])
        initial_guess_3 = np.clip([self.ampl0[2]] * self.control_horizon,
                                 self.control_bounds[0], self.control_bounds[1])
        
        def control_func_1(t, args):
            idx = min(int((t - t_start) / self.dt), len(initial_guess_1) - 1)
            return initial_guess_1[idx]
        
        def control_func_2(t, args):
            idx = min(int((t - t_start) / self.dt), len(initial_guess_2) - 1)
            return initial_guess_2[idx]
        
        def control_func_3(t, args):
            idx = min(int((t - t_start) / self.dt), len(initial_guess_3) - 1)
            return initial_guess_3[idx]
        
        # Create Hamiltonian with initial guess: H0 + u1*H1 + u2*H2 + u3*H3
        H_guess = [
            self.H0, 
            [self.H1, control_func_1], 
            [self.H2, control_func_2],
            [self.H3, control_func_3]
        ]
        
        # Create objective for this MPC step
        objective = krotov.Objective(
            initial_state=current_state,
            target=self.target_state,
            H=H_guess
        )
        
        # Pulse options WITH BOUND CONSTRAINTS [-1, 1] for all 3 controls
        pulse_options = {
            H_guess[1][1]: dict(
                lambda_a=5, 
                update_shape=self.shape_function,
                bounds=(-1.0, 1.0)
            ),
            H_guess[2][1]: dict(
                lambda_a=5, 
                update_shape=self.shape_function,
                bounds=(-1.0, 1.0)
            ),
            H_guess[3][1]: dict(
                lambda_a=5, 
                update_shape=self.shape_function,
                bounds=(-1.0, 1.0)
            ),
        }
        
        # Optimize using Krotov for this MPC window
        try:
            opt_result = krotov.optimize_pulses(
                [objective],
                pulse_options=pulse_options,
                tlist=opt_tlist,
                propagator=krotov.propagators.expm,
                chi_constructor=krotov.functionals.chis_ss,
                info_hook=krotov.info_hooks.print_table(J_T=krotov.functionals.J_T_ss),
                check_convergence=krotov.convergence.Or(
                    krotov.convergence.value_below('1e-3', name='J_T'),
                    krotov.convergence.check_monotonic_error,
                ),
                store_all_pulses=True,
                iter_stop=5  # Reduced iterations for faster MPC
            )
            
            # Extract optimized controls (now 3 controls)
            optimized_controls_1 = opt_result.optimized_controls[0]
            optimized_controls_2 = opt_result.optimized_controls[1]
            optimized_controls_3 = opt_result.optimized_controls[2]  # Corrected index
            
            # Ensure bounds are satisfied
            optimized_controls_1 = np.clip(optimized_controls_1, self.control_bounds[0], self.control_bounds[1])
            optimized_controls_2 = np.clip(optimized_controls_2, self.control_bounds[0], self.control_bounds[1])
            optimized_controls_3 = np.clip(optimized_controls_3, self.control_bounds[0], self.control_bounds[1])
            
            return optimized_controls_1, optimized_controls_2, optimized_controls_3
            
        except Exception as e:
            print(f"Optimization failed: {e}")
            # Return initial guess if optimization fails
            return initial_guess_1, initial_guess_2, initial_guess_3
    
    def run_mpc(self):
        """Run the MPC controller with bound constraints"""
        print("Starting 3-control MPC quantum control with bound constraints [-1, 1]...")
        
        current_state = self.initial_state
        current_time = 0.0
        time_step = 0
        
        # Initialize tracking
        self.mpc_fidelities = [fidelity(current_state, self.target_state)]
        self.mpc_states = [current_state]
        self.mpc_controls_1 = []
        self.mpc_controls_2 = []
        self.mpc_controls_3 = []
        self.control_times = [0.0]
        
        while current_time < self.T and time_step < len(self.tlist) - 1:
            print(f"MPC Step {time_step + 1}, Time: {current_time:.2f}/{self.T:.2f}")
            
            # Optimize controls for current MPC window (now returns 3 controls)
            controls_1, controls_2, controls_3 = self.optimize_controls_mpc_step(current_state, current_time)
            
            # Apply first control step (receding horizon)
            applied_control_1 = controls_1[0] if len(controls_1) > 0 else 0.0
            applied_control_2 = controls_2[0] if len(controls_2) > 0 else 0.0
            applied_control_3 = controls_3[0] if len(controls_3) > 0 else 0.0
            
            # Store controls BEFORE propagation
            self.mpc_controls_1.append(applied_control_1)
            self.mpc_controls_2.append(applied_control_2)
            self.mpc_controls_3.append(applied_control_3)
            
            # Apply control and propagate one step
            def control_func_1(t, args):
                return applied_control_1
            
            def control_func_2(t, args):
                return applied_control_2
            
            def control_func_3(t, args):
                return applied_control_3
            
            # Full Hamiltonian: H0 + u1*H1 + u2*H2 + u3*H3
            H_step = [
                self.H0, 
                [self.H1, control_func_1], 
                [self.H2, control_func_2],
                [self.H3, control_func_3]
            ]
            
            # Propagate one time step
            result = mesolve(H_step, current_state, [current_time, current_time + self.dt], [], [])
            current_state = result.states[-1]
            
            # Store results
            self.mpc_states.append(current_state)
            current_fidelity = fidelity(current_state, self.target_state)
            self.mpc_fidelities.append(current_fidelity)
            self.control_times.append(current_time + self.dt)
            
            print(f"  Applied controls: u1={applied_control_1:.3f}, u2={applied_control_2:.3f}, u3={applied_control_3:.3f}")
            print(f"  Current fidelity: {current_fidelity:.6f}")
            
            # Update time
            current_time += self.dt
            time_step += 1
        
        print("MPC completed!")
        
    def plot_results(self):
        """Plot MPC results with bound constraints for all 3 controls"""
        # Use control_times for plotting (correct dimension)
        plot_times = np.array(self.control_times[:len(self.mpc_controls_1)])
        
        plt.figure(figsize=(18, 12))
        
        # Plot fidelity
        plt.subplot(4, 1, 1)
        plt.plot(self.control_times[:len(self.mpc_fidelities)], self.mpc_fidelities, 'b-', linewidth=2)
        plt.xlabel('Time')
        plt.ylabel('Fidelity')
        plt.title('MPC: Fidelity vs Time with Bound Constraints [-1, 1]')
        plt.grid(True)
        plt.ylim(0, 1.05)
        
        # Plot control 1 (σ_x) with bounds
        plt.subplot(4, 1, 2)
        plt.plot(plot_times, self.mpc_controls_1, 'r-', label='Control 1 (σ_x)', linewidth=2)
        plt.axhline(y=1.0, color='gray', linestyle='--', alpha=0.7, label='Upper bound')
        plt.axhline(y=-1.0, color='gray', linestyle='--', alpha=0.7, label='Lower bound')
        plt.fill_between(plot_times, -1.0, 1.0, color='gray', alpha=0.1)
        plt.xlabel('Time')
        plt.ylabel('Amplitude')
        plt.title('MPC: Control Field 1 (σ_x) with Bound Constraints')
        plt.legend()
        plt.grid(True)
        plt.ylim(-1.2, 1.2)
        
        # Plot control 2 (σ_y) with bounds
        plt.subplot(4, 1, 3)
        plt.plot(plot_times, self.mpc_controls_2, 'g-', label='Control 2 (σ_y)', linewidth=2)
        plt.axhline(y=1.0, color='gray', linestyle='--', alpha=0.7, label='Upper bound')
        plt.axhline(y=-1.0, color='gray', linestyle='--', alpha=0.7, label='Lower bound')
        plt.fill_between(plot_times, -1.0, 1.0, color='gray', alpha=0.1)
        plt.xlabel('Time')
        plt.ylabel('Amplitude')
        plt.title('MPC: Control Field 2 (σ_y) with Bound Constraints')
        plt.legend()
        plt.grid(True)
        plt.ylim(-1.2, 1.2)
        
        # Plot control 3 (σ_z) with bounds
        plt.subplot(4, 1, 4)
        plt.plot(plot_times, self.mpc_controls_3, 'b-', label='Control 3 (σ_z)', linewidth=2)
        plt.axhline(y=1.0, color='gray', linestyle='--', alpha=0.7, label='Upper bound')
        plt.axhline(y=-1.0, color='gray', linestyle='--', alpha=0.7, label='Lower bound')
        plt.fill_between(plot_times, -1.0, 1.0, color='gray', alpha=0.1)
        plt.xlabel('Time')
        plt.ylabel('Amplitude')
        plt.title('MPC: Control Field 3 (σ_z) with Bound Constraints')
        plt.legend()
        plt.grid(True)
        plt.ylim(-1.2, 1.2)
        
        plt.tight_layout()
        plt.show()
        
        # Verify bounds are satisfied
        self.verify_bounds()
        
        # Final results
        final_fidelity = self.mpc_fidelities[-1] if self.mpc_fidelities else 0.0
        print(f"\nFinal fidelity: {final_fidelity:.6f}")
        print(f"Final time: {self.control_times[-1]:.2f}")
    
    def verify_bounds(self):
        """Verify that control bounds are satisfied for all 3 controls"""
        controls_1 = np.array(self.mpc_controls_1)
        controls_2 = np.array(self.mpc_controls_2)
        controls_3 = np.array(self.mpc_controls_3)
        
        violations_1 = np.sum((controls_1 < -1.0) | (controls_1 > 1.0))
        violations_2 = np.sum((controls_2 < -1.0) | (controls_2 > 1.0))
        violations_3 = np.sum((controls_3 < -1.0) | (controls_3 > 1.0))
        
        print(f"\n=== BOUND CONSTRAINT VERIFICATION ===")
        print(f"Control 1 (σ_x) violations: {violations_1} ({(violations_1/len(controls_1)*100):.1f}%)")
        print(f"Control 2 (σ_y) violations: {violations_2} ({(violations_2/len(controls_2)*100):.1f}%)")
        print(f"Control 3 (σ_z) violations: {violations_3} ({(violations_3/len(controls_3)*100):.1f}%)")
        print(f"Control 1 range: [{np.min(controls_1):.3f}, {np.max(controls_1):.3f}]")
        print(f"Control 2 range: [{np.min(controls_2):.3f}, {np.max(controls_2):.3f}]")
        print(f"Control 3 range: [{np.min(controls_3):.3f}, {np.max(controls_3):.3f}]")
        
        if violations_1 == 0 and violations_2 == 0 and violations_3 == 0:
            print("✓ All controls satisfy bound constraints [-1, 1]")
        else:
            print("✗ Some controls violate bound constraints")

    def analyze_performance(self):
        """Analyze controller performance"""
        print("\n" + "="*60)
        print("PERFORMANCE ANALYSIS")
        print("="*60)
        
        final_fidelity = self.mpc_fidelities[-1]
        print(f"Final Fidelity: {final_fidelity:.6f}")
        print(f"Infidelity: {1 - final_fidelity:.3e}")
        
        # Control statistics
        control_energy_1 = np.sum(np.array(self.mpc_controls_1)**2) * self.dt
        control_energy_2 = np.sum(np.array(self.mpc_controls_2)**2) * self.dt
        control_energy_3 = np.sum(np.array(self.mpc_controls_3)**2) * self.dt
        total_energy = control_energy_1 + control_energy_2 + control_energy_3
        
        print(f"\nControl Energy Analysis:")
        print(f"Control 1 (σ_x) Energy: {control_energy_1:.4f}")
        print(f"Control 2 (σ_y) Energy: {control_energy_2:.4f}")
        print(f"Control 3 (σ_z) Energy: {control_energy_3:.4f}")
        print(f"Total Control Energy: {total_energy:.4f}")
        
        # Effective Hamiltonian analysis
        avg_u3 = np.mean(self.mpc_controls_3)
        print(f"\nEffective Hamiltonian Analysis:")
        print(f"Drift strength ω: {self.omega}")
        print(f"Average u₃ control: {avg_u3:.3f}")
        print(f"Effective z-component: {self.omega + avg_u3:.3f}")

# Run the simulation
if __name__ == "__main__":
    # Initialize MPC controller with bound constraints for 3-control system
    mpc_controller = QuantumMPC_Krotov(
        omega=1.0,
        ampl0=[0.2, 0.2, 0.2],  # Initial amplitudes for u1, u2, u3
        T=5.0,
        N=100,
        prediction_horizon=15,
        control_horizon=8
    )
    
    # Run MPC
    start_time = time()
    mpc_controller.run_mpc()
    end_time = time()
    
    print(f"\nMPC optimization completed in {end_time - start_time:.2f} seconds")
    
    # Plot results with bound constraints
    mpc_controller.plot_results()
    
    # Performance analysis
    mpc_controller.analyze_performance()
    
    # Access results
    print(f"\nControl arrays lengths:")
    print(f"Control 1 (σ_x): {len(mpc_controller.mpc_controls_1)}")
    print(f"Control 2 (σ_y): {len(mpc_controller.mpc_controls_2)}")
    print(f"Control 3 (σ_z): {len(mpc_controller.mpc_controls_3)}")
    print(f"Time points: {len(mpc_controller.control_times)}")
    
    # Example values
    print(f"\nFirst few control values:")
    print(f"Control 1: {mpc_controller.mpc_controls_1[:5]}")
    print(f"Control 2: {mpc_controller.mpc_controls_2[:5]}")
    print(f"Control 3: {mpc_controller.mpc_controls_3[:5]}")