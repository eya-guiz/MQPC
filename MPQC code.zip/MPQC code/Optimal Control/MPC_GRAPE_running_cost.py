# -*- coding: utf-8 -*-
"""
MPC Algorithm with GRAPE optimization in each iteration
"""

import numpy as np
import matplotlib.pyplot as plt
from qutip import *
import time

# Time parameters
t_end = 5
T = 100
dt = t_end / T
tlist = np.linspace(0, t_end, T)

# MPC parameters
L = 20  # Prediction horizon
m = 1   # Control application steps
nb_opts = int(np.ceil(T / m))

# System parameters
nb_inputs = 2
omega = -0.5
ampl0 = [0.2, 0.2]  # Initial guess amplitude

# Initial and target states
psi0 = basis(2, 0)
#psi_target = basis(2, 1)
psi_target = (basis(2,0) + basis(2,1)).unit()
u_ref = [0.0, 0.0]
# psi_target = (basis(2, 0) + basis(2, 1)).unit()  # superposition state

# #######################
# # Desired Bloch vector (normalized)
# r_vec = np.array([0, 1/np.sqrt(2), 1/np.sqrt(2)])  # (x, y, z)
# x, y, z = r_vec

# # Compute control inputs for H = u1 * sx + u2 * sy + omega * sz
# u1 = 0  # because x = 0
# u2 = omega * y / z  # = 1.0

# # Build the Hamiltonian
# H = u1 * sigmax() + u2 * sigmay() + omega * sigmaz()

# # Create eigenstate from Bloch vector
# theta = np.arccos(z)           # theta = arccos(z)
# phi = np.arctan2(y, x)         # phi = arctan2(y, x) = pi/2

# psi_target = np.cos(theta/2) * basis(2, 0) + np.exp(1j * phi) * np.sin(theta/2) * basis(2, 1)
# psi_target = psi_target.unit()  # normalize just in case

# # Check: is psi_ref an eigenstate?
# eigval = (psi_target.dag() * H * psi_target).full().item() 

# u_ref = np.array([0,omega])



#######################

H0 = omega * sigmaz()
H_controls = [sigmax(), sigmay()]
proj0, proj1 = (ket2dm(basis(2, i)) for i in range(2))

# === GRAPE Parameters ===
max_iter = 100
learning_rate = 0.1
alpha = 0.0  # control penalty

# === Helper Functions ===
def fidelity(psi, psi_target):
    return np.abs((psi_target.dag() * psi)[0, 0])**2

def forward(psi0, u, H0, Hcs, dt, N):
    psi_list = [psi0]
    psi = psi0
    for j in range(N):
        H = H0 + sum(u[k, j] * Hcs[k] for k in range(len(Hcs)))
        U = (-1j * H * dt).expm()
        psi = (U * psi).unit()
        psi_list.append(psi)
    return psi_list

def backward(psi_target, u, H0, Hcs, dt, N):
    lam = psi_target
    lam_list = [None] * (N + 1)
    lam_list[N] = lam
    for j in reversed(range(N)):
        H = H0 + sum(u[k, j] * Hcs[k] for k in range(len(Hcs)))
        Udag = (-1j * H * dt).expm().dag()
        lam = (Udag * lam).unit()
        lam_list[j] = lam
    return lam_list

def grape_optimize(psi0, psi_target, H0, Hcs, dt, N, initial_guess, max_iter=100, learning_rate=0.1):
    u = initial_guess.copy()
    fidelity_log = []
    
    for it in range(max_iter):
        # Forward propagation
        psi_list = forward(psi0, u, H0, Hcs, dt, N)
        psi_final = psi_list[-1]
        F = fidelity(psi_final, psi_target)
        fidelity_log.append(F)

        if (1 - F) < 1e-4:
            break

        # Backward propagation
        lam_list = backward(psi_target, u, H0, Hcs, dt, N)

        # Gradient calculation
        grad = np.zeros_like(u)
        overlap = (psi_target.dag() * psi_final)[0, 0]
        for j in range(N):
            for k in range(len(Hcs)):
                #grad[k, j] = 2 * np.imag((lam_list[j+1].dag() * Hcs[k] * psi_list[j])[0, 0] * overlap.conjugate())
                #grad[k, j] += 2 * alpha * (u[k,-1] - u_ref[k]) * overlap.conjugate()
                grad[k, j] = 2 * np.imag((lam_list[j+1].dag() * Hcs[k] * psi_list[j])[0, 0] )
                grad[k, j] += 2 * alpha * (u[k,-1] - u_ref[k])
        # Terminal input cost - not relevant
        # for k in range(len(Hcs)):
        #     grad[k, -1] += 2 * 1e-4 * (u[k, -1] - u_ref[k]) * np.imag(overlap.conjugate()) # Only apply to final time step
        
        # # Optional: Add L2 regularization to prevent large pulses
        grad -= 0.1 * u # doesn't work well for larger learning rates
        
        # Update control pulses with bounds
        u = learning_rate * grad
        u = np.clip(u, -1.0, 1.0)  # Enforce bounds
        
    return u, F

# Storage
mpc_control = np.zeros((nb_inputs, T))
current_state = psi0
running_time_table = []

# === MPC Loop ===
total_start_time = time.time()
for step in range(nb_opts):
    print(f"\n=== MPC Step {step + 1}/{nb_opts} ===")
    t_idx = step * m
    if t_idx >= T:
        break

    window_end = min(t_idx + L, T)
    window_size = window_end - t_idx
    window_tlist = np.linspace(0, dt * window_size, window_size)
    apply_steps = min(m, window_size)

    # Initial guess for optimization
    guess = np.zeros((nb_inputs, window_size))
    if step == 0:
        for i in range(nb_inputs):
            guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, window_size))
    else:
        for i in range(nb_inputs):
            control_teil = optimized_u[i, apply_steps:]
            n_fill = min(len(control_teil), window_size)
            guess[i, :n_fill] = control_teil[:n_fill]

    # --- Time this optimization ---
    step_start = time.time()

    # Run GRAPE optimization
    optimized_u, final_fidelity = grape_optimize(
        current_state, psi_target, H0, H_controls, 
        dt, window_size, guess, max_iter, learning_rate
    )
    
    step_end = time.time()
    elapsed = step_end - step_start
    running_time_table.append(elapsed)
    
    
    print(f"Step {step + 1} optimization completed in {elapsed:.2f} seconds")
    print(f"Final fidelity: {final_fidelity:.6f}")

    # Store the controls to be applied
    for i in range(nb_inputs):
        mpc_control[i, t_idx:t_idx+apply_steps] = optimized_u[i, :apply_steps]

    # Forward propagate system for m steps
    for local_step in range(apply_steps):
        H = H0
        for i in range(nb_inputs):
            H += mpc_control[i, t_idx + local_step] * H_controls[i]
        U = (-1j * H * dt).expm()
        current_state = U * current_state

# Runtime Results
total_runtime_sum = sum(running_time_table)
print(f"Total runtime of all runs: {total_runtime_sum:.2f} s")


# === Final Simulation ===
state = psi0
populations = []
fidelities = []

for t in range(T):
    H = H0
    for i in range(nb_inputs):
        H += mpc_control[i, t] * H_controls[i]
    U = (-1j * H * dt).expm()
    state = U * state
    fidelities.append(fidelity(state, psi_target))
    populations.append([expect(proj0, state), expect(proj1, state)])

populations = np.array(populations)

# === Plots  ===
plt.figure(figsize=(12, 8))

# Population Plot
plt.subplot(2, 2, 1)
plt.plot(tlist, populations[:, 0], label="Population in |0>")
plt.plot(tlist, populations[:, 1], label="Population in |1>")
plt.xlabel("Time", fontsize=16)
plt.ylabel("Population", fontsize=16)
plt.title("A", fontsize=18, loc = 'left')
#plt.title("State Populations", fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.legend(fontsize=16)
plt.grid(True)

# Fidelity Plot
plt.subplot(2, 2, 2)
plt.plot(tlist, fidelities, label="Fidelity")
plt.axhline(y=1.0, color='r', linestyle='--', label="Target")
plt.xlabel("Time", fontsize=16)
plt.ylabel("Fidelity", fontsize=16)
#plt.title("Fidelity Over Time", fontsize=16)
plt.title("B", fontsize=18, loc = 'left')
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.legend(fontsize=16)
plt.grid(True)

# Control Fields
plt.subplot(2, 1, 2)
for i in range(nb_inputs):
    plt.plot(tlist, mpc_control[i], label=f"Control Field {i+1}")
plt.xlabel("Time", fontsize=16)
plt.ylabel("Amplitude", fontsize=16)
plt.title("C", fontsize=18, loc= 'left')
#plt.title("Optimized Control Fields (MPC + GRAPE)", fontsize=16)
plt.xticks(fontsize=16)
plt.yticks(fontsize=16)
plt.legend(fontsize=16)
plt.grid(True)

plt.tight_layout()
plt.show()

print(f"Final Fidelity: {fidelities[-1]:.9f}")
