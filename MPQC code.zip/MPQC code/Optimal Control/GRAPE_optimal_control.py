# -*- coding: utf-8 -*-
"""
Full-horizon GRAPE Optimal Control
"""

"""
GRAPE (Gradient Ascent Pulse Engineering) Algorithm Implementation
for Quantum Optimal Control of a Single Qubit

Reference:
N. Khaneja et al., "Optimal control of coupled spin dynamics: 
Design of NMR pulse sequences by gradient ascent algorithms",
J. Magn. Reson. 172:296-305 (2005). doi:10.1016/j.jmr.2004.11.004
"""


import numpy as np
import matplotlib.pyplot as plt
from qutip import *
import time

# ===== Parameters =====
t_end = 5
T = 100
dt = t_end / T
tlist = np.linspace(0, t_end, T)

nb_inputs = 2
omega = -0.5
ampl0 = [0.2, 0.2]  # Initial guess amplitude

# Initial and target states
psi0 = basis(2, 0)
#psi_target = basis(2, 1)
psi_target = (basis(2,0) + basis(2,1)).unit()
u_ref = [0.0, 0.0]

# System Hamiltonians
H0 = omega * sigmaz()
H_controls = [sigmax(), sigmay()]
proj0, proj1 = (ket2dm(basis(2, i)) for i in range(2))

# GRAPE Parameters
max_iter = 300
learning_rate = 0.1
alpha = 1e-4  # control penalty

# ===== Helper Functions =====
def fidelity(psi, psi_target):
    return np.abs((psi_target.dag() * psi)[0, 0])**2

def forward(psi0, u, H0, Hcs, dt, N):
    psi_list = [psi0]
    psi = psi0
    for j in range(N):
        H = H0 + sum(u[k, j] * Hcs[k] for k in range(len(Hcs)))
        U = (-1j * H * dt).expm()
        psi = (U * psi).unit()
        psi_list.append(psi)
    return psi_list

def backward(psi_target, u, H0, Hcs, dt, N):
    lam = psi_target
    lam_list = [None] * (N + 1)
    lam_list[N] = lam
    for j in reversed(range(N)):
        H = H0 + sum(u[k, j] * Hcs[k] for k in range(len(Hcs)))
        Udag = (-1j * H * dt).expm().dag()
        lam = (Udag * lam).unit()
        lam_list[j] = lam
    return lam_list

def grape_optimize(psi0, psi_target, H0, Hcs, dt, N, initial_guess, max_iter=100, learning_rate=0.1):
    u = initial_guess.copy()
    fidelity_log = []
    
    for it in range(max_iter):
        # Forward propagation
        psi_list = forward(psi0, u, H0, Hcs, dt, N)
        psi_final = psi_list[-1]
        F = fidelity(psi_final, psi_target)
        fidelity_log.append(F)

        if (1 - F) < 1e-4:
            print(f"Converged at iteration {it}")
            break

        # Backward propagation
        lam_list = backward(psi_target, u, H0, Hcs, dt, N)

        # Gradient calculation
        grad = np.zeros_like(u)
        overlap = (psi_target.dag() * psi_final)[0, 0]
        for j in range(N):
            for k in range(len(Hcs)):
                # grad[k, j] = 2 * np.imag((lam_list[j+1].dag() * Hcs[k] * psi_list[j])[0, 0] * overlap.conjugate())
                # grad[k, j] += 2 * alpha * (u[k, j] - u_ref[k]) * overlap.conjugate()
                grad[k, j] = 2 * np.imag((lam_list[j+1].dag() * Hcs[k] * psi_list[j])[0, 0])
                grad[k, j] += 2 * alpha * (u[k, j] - u_ref[k])      
        # # Optional: Add L2 regularization to prevent large pulses
        grad -= 0.1 * u # doesn't work well for larger learning rates
        
        # Update control pulses
        u += learning_rate * grad
        u = np.clip(u, -1.0, 1.0)
        
    return u, fidelity_log

# ===== Run GRAPE over Full Horizon =====
initial_guess = np.zeros((nb_inputs, T))
for i in range(nb_inputs):
    initial_guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, T))

start_time = time.time()
u_opt, fidelity_log = grape_optimize(psi0, psi_target, H0, H_controls, dt, T, initial_guess, max_iter, learning_rate)
end_time = time.time()

print(f"Optimization completed in {end_time - start_time:.2f} seconds")
print(f"Final Fidelity: {fidelity_log[-1]:.9f}")

# ===== Simulate Optimal Controls =====
state = psi0
populations = []
fidelities = []

for t in range(T):
    H = H0
    for i in range(nb_inputs):
        H += u_opt[i, t] * H_controls[i]
    U = (-1j * H * dt).expm()
    state = U * state
    fidelities.append(fidelity(state, psi_target))
    populations.append([expect(proj0, state), expect(proj1, state)])

populations = np.array(populations)

# ===== Plots (Bigger Labels & Titles) =====
plt.figure(figsize=(12, 9))

# Populations
plt.subplot(3, 1, 1)
plt.plot(tlist, populations[:, 0], label="Population in |0>")
plt.plot(tlist, populations[:, 1], label="Population in |1>")
plt.xlabel("Time", fontsize=16)
#plt.ylabel("Population", fontsize=16)
plt.title("A", fontsize=18)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(fontsize=14)
plt.grid(True)

# Fidelity
plt.subplot(3, 1, 2)
plt.plot(tlist, fidelities, label="Fidelity", color='r')
plt.axhline(y=1.0, color='k', linestyle='--', label="Target")
plt.xlabel("Time", fontsize=16)
plt.ylabel("Fidelity", fontsize=16)
plt.title("Fidelity Over Time", fontsize=18)
plt.title("B", fontsize=18)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(fontsize=14)
plt.grid(True)

# Controls
plt.subplot(3, 1, 3)
for i in range(nb_inputs):
    plt.plot(tlist, u_opt[i], label=f"Control Field {i+1}")
plt.xlabel("Time", fontsize=16)
plt.ylabel("Amplitude", fontsize=16)
#plt.title("Optimized Control Fields (Full-Horizon GRAPE)", fontsize=18)
plt.title("C", fontsize=18)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
plt.legend(fontsize=14)
plt.grid(True)

plt.tight_layout()
plt.show()


####################### Simulation to compute total cost ################################
# Simulate system with optimal control to get total cost, fidelity, populations

current_x = np.array([np.real(psi0.full()[0,0]), np.imag(psi0.full()[0,0]),
                      np.real(psi0.full()[1,0]), np.imag(psi0.full()[1,0])])  # map |ψ> to real vector form
total_cost_accum = 0.0
fidelity_traj = []
pop0_traj = []
pop1_traj = []


for k in range(T):
    # Control at step k
    uk = u_opt[:, k]

    # Build Hamiltonian
    H = H0 + sum(uk[i] * H_controls[i] for i in range(nb_inputs))
    U = (-1j * H * dt).expm()

    # Apply step
    psi_ket = Qobj(current_x[0:2] + 1j*current_x[2:4])  # reconstruct ket
    psi_ket = (U * psi_ket).unit()
    current_x = np.hstack([np.real(psi_ket.full()), np.imag(psi_ket.full())]).flatten()

    # Fidelity
    fid = fidelity(psi_ket, psi_target)
    fidelity_traj.append(fid)

    # Stage cost
    stage_cost = 1.0 - fid
    total_cost_accum += stage_cost

    # Populations
    pop0_traj.append(expect(proj0, psi_ket))
    pop1_traj.append(expect(proj1, psi_ket))

# ===== Print results =====
print(f"Total Cost: {total_cost_accum:.4f}")


