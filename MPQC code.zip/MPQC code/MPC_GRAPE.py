# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 02:30:12 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Efficient MPC with GRAPE for Quantum Optimal Control
Terminal Eqaulity Constraint (TEC) enforced through backpropagation
Here: Terminal Cost
"""

import numpy as np
import matplotlib.pyplot as plt
from qutip import *
import time

# Standard basis states
ket0 = basis(2, 0)       # |0>
ket1 = basis(2, 1)       # |1>

# Superposition states
ket_plus  = (ket0 + ket1).unit()        # |+>
ket_minus = (ket0 - ket1).unit()        # |->

ket_yplus  = (ket0 + 1j * ket1).unit()  # |y+>
ket_yminus = (ket0 - 1j * ket1).unit()  # |y->

class QuantumMPC_GRAPE:
    def __init__(self, t_end=5.0, T=100, L=10, m=5, max_iter=30, learning_rate=0.2):
        """
        Initialize MPC-GRAPE controller
        
        Parameters:
        t_end: total simulation time
        T: number of time steps
        L: prediction horizon steps
        m: control application steps
        max_iter: GRAPE iterations per MPC step
        learning_rate: GRAPE learning rate
        """
        # Time parameters
        self.t_end = t_end
        self.T = T
        self.dt = t_end / T
        self.tlist = np.linspace(0, t_end, T)
        
        # MPC parameters
        self.L = L  # Prediction horizon
        self.m = m   # Control application steps
        self.nb_opts = int(np.ceil(T / m))
        
        # GRAPE parameters
        self.max_iter = max_iter
        self.learning_rate = learning_rate
        self.R = 1e-4
        self.alpha = 1
        
        # System parameters
        self.nb_inputs = 3
        self.omega = -0.5
        self.ampl0 = [0.2, 0.2, 0.2]  # Initial guess amplitude
        
        # Quantum system
        self.H0 = self.omega * sigmaz()
        self.H_controls = [sigmax(), sigmay(), sigmaz()]
        
        # States
        self.psi0 = basis(2, 0)
        self.psi_target = ket_yminus
        
        # Reference Input
        self.u_ref = np.zeros((3,1))
        
        # Storage
        self.mpc_control = np.zeros((self.nb_inputs, self.T))
        self.fidelities = []
        self.populations = []
        self.runtimes = []
        
    def fidelity(self, psi, psi_target):
        """Compute fidelity between states"""
        return np.abs((psi_target.dag() * psi)[0, 0])**2
    
    def forward_propagation(self, psi0, u, H0, Hcs, dt, N):
        """Efficient forward propagation"""
        psi = psi0
        psi_list = [psi]
        
        for j in range(N):
            # Build Hamiltonian
            H = H0
            for k in range(len(Hcs)):
                H += u[k, j] * Hcs[k]
            
            # Time evolution
            U = (-1j * H * dt).expm()
            psi = U * psi
            psi_list.append(psi)
            
        return psi_list
    
    def backward_propagation(self, psi_target, u, H0, Hcs, dt, N):
        """Efficient backward propagation"""
        lam = psi_target
        lam_list = [None] * (N + 1)
        lam_list[N] = lam
        
        for j in reversed(range(N)):
            # Build Hamiltonian (same as forward)
            H = H0
            for k in range(len(Hcs)):
                H += u[k, j] * Hcs[k]
            
            # Backward evolution (adjoint)
            Udag = (1j * H * dt).expm()  # Note: +1j for adjoint
            lam = Udag * lam
            lam_list[j] = lam
            
        return lam_list
    
    def grape_optimize(self, psi0, psi_target, H0, Hcs, dt, N, initial_guess):
        """Optimize controls using GRAPE algorithm"""
        u = initial_guess.copy()
        best_fidelity = 0
        best_u = u.copy()
        
        for it in range(self.max_iter):
            # Forward propagation
            psi_list = self.forward_propagation(psi0, u, H0, Hcs, dt, N)
            psi_final = psi_list[-1]
            F = self.fidelity(psi_final, psi_target)
            
            # Store best solution
            if F > best_fidelity:
                best_fidelity = F
                best_u = u.copy()
            
            if (1 - F) < 1e-6:
                break
                
            # Backward propagation
            lam_list = self.backward_propagation(psi_target, u, H0, Hcs, dt, N)
            
            # Gradient calculation
            grad = np.zeros_like(u)
            overlap = (psi_target.dag() * psi_final)[0, 0]  # final fidelity weight
            for j in range(N):
                for k in range(nb_inputs):
                    grad[k, j] = 2 * np.imag((lam_list[j+1].dag() * Hcs[k] * psi_list[j])[0, 0]*overlap.conjugate())
                    
            # Update control pulses with bounds
            u += self.learning_rate * grad
            u = np.clip(u, -1.0, 1.0)  # Enforce bounds
            
        return best_u, best_fidelity
    
    def run_mpc(self):
        """Run the MPC-GRAPE controller"""
        print("Starting MPC-GRAPE quantum control...")
        print(f"Parameters: T={self.T}, L={self.L}, m={self.m}, max_iter={self.max_iter}")
        
        current_state = self.psi0
        total_start_time = time.time()
        
        # Initialize fidelity and population tracking
        self.fidelities = [self.fidelity(current_state, self.psi_target)]
        self.populations = [[
            expect(ket2dm(basis(2, 0)), current_state),
            expect(ket2dm(basis(2, 1)), current_state)
        ]]
        
        for step in range(self.nb_opts):
            t_idx = step * self.m
            if t_idx >= self.T:
                break
                
            window_end = min(t_idx + self.L, self.T)
            window_size = window_end - t_idx
            apply_steps = min(self.m, window_size)
            
            # Initial guess for optimization - FIXED THE BUG HERE
            guess = np.zeros((self.nb_inputs, window_size))
            if step == 0:
                # First step: use constant initial guess
                for i in range(self.nb_inputs):
                    guess[i, :] = self.ampl0[i] * np.ones(window_size)
            else:
                # Warm start from previous optimization
                prev_start = max(0, t_idx - self.L)
                prev_controls = self.mpc_control[i, prev_start:prev_start + window_size]
                if len(prev_controls) == window_size:
                    for i in range(self.nb_inputs):
                        guess[i, :] = prev_controls
                else:
                    # Pad with initial guess if needed
                    for i in range(self.nb_inputs):
                        guess[i, :] = self.ampl0[i] * np.ones(window_size)
            
            # Run GRAPE optimization
            step_start = time.time()
            optimized_u, final_fidelity = self.grape_optimize(
                current_state, self.psi_target, self.H0, self.H_controls, 
                self.dt, window_size, guess
            )
            step_time = time.time() - step_start
            self.runtimes.append(step_time)
            
            print(f"Step {step+1}: Fidelity={final_fidelity:.6f}, Time={step_time:.3f}s")
            
            # Store controls
            for i in range(self.nb_inputs):
                self.mpc_control[i, t_idx:t_idx+apply_steps] = optimized_u[i, :apply_steps]
            
            # Forward propagate system for applied steps
            for local_step in range(apply_steps):
                H = self.H0
                for i in range(self.nb_inputs):
                    H += self.mpc_control[i, t_idx + local_step] * self.H_controls[i]
                U = (-1j * H * self.dt).expm()
                current_state = U * current_state
                
                # Store results
                self.fidelities.append(self.fidelity(current_state, self.psi_target))
                self.populations.append([
                    expect(ket2dm(basis(2, 0)), current_state),
                    expect(ket2dm(basis(2, 1)), current_state)
                ])
        
        total_time = time.time() - total_start_time
        print(f"\nMPC-GRAPE completed in {total_time:.2f} seconds")
        print(f"Average step time: {np.mean(self.runtimes):.3f} seconds")
        print(f"Final fidelity: {self.fidelities[-1]:.9f}")
        
        return total_time
    
    def plot_results(self):
        """Plot the results"""
        populations = np.array(self.populations)
        time_points = np.linspace(0, self.t_end, len(populations))
        
        plt.figure(figsize=(15, 10))
        
        # Population Plot
        plt.subplot(2, 2, 1)
        plt.plot(time_points, populations[:, 0], label="Population in |0>", linewidth=2)
        plt.plot(time_points, populations[:, 1], label="Population in |1>", linewidth=2)
        plt.xlabel("Time")
        plt.ylabel("Population")
        plt.title("State Populations")
        plt.legend()
        plt.grid(True)
        
        # Fidelity Plot
        plt.subplot(2, 2, 2)
        plt.plot(time_points, self.fidelities, label="Fidelity", linewidth=2, color='purple')
        plt.axhline(y=1.0, color='r', linestyle='--', label="Target")
        plt.xlabel("Time")
        plt.ylabel("Fidelity")
        plt.title("Fidelity Over Time")
        plt.legend()
        plt.grid(True)
        
        # Control Fields
        plt.subplot(2, 1, 2)
        for i in range(self.nb_inputs):
            plt.plot(self.tlist, self.mpc_control[i], label=f"Control Field {i+1}", linewidth=2)
        plt.xlabel("Time")
        plt.ylabel("Amplitude")
        plt.title("Optimized Control Fields (MPC + GRAPE)")
        plt.legend()
        plt.grid(True)
        
        plt.tight_layout()
        plt.show()
        
        # Runtime statistics
        if self.runtimes:
            plt.figure(figsize=(10, 4))
            plt.plot(range(1, len(self.runtimes)+1), self.runtimes, 'o-', linewidth=2)
            plt.xlabel("MPC Step")
            plt.ylabel("Runtime (s)")
            plt.title("Optimization Time per MPC Step")
            plt.grid(True)
            plt.show()

    def analyze_performance(self):
        """Analyze controller performance"""
        print("\n" + "="*50)
        print("PERFORMANCE ANALYSIS")
        print("="*50)
        
        # Final results
        final_fidelity = self.fidelities[-1] if self.fidelities else 0.0
        print(f"Final Fidelity: {final_fidelity:.9f}")
        print(f"Infidelity: {1 - final_fidelity:.3e}")
        
        # Control statistics
        control_energy = np.sum(self.mpc_control**2) * self.dt
        print(f"Total Control Energy: {control_energy:.4f}")
        
        # Runtime statistics
        total_time = sum(self.runtimes) if self.runtimes else 0.0
        avg_time = np.mean(self.runtimes) if self.runtimes else 0.0
        print(f"Total Optimization Time: {total_time:.2f} s")
        print(f"Average per Step: {avg_time:.3f} s")
        print(f"Number of MPC Steps: {len(self.runtimes)}")

# Run the simulation
if __name__ == "__main__":
    # Initialize MPC controller with optimized parameters
    mpc = QuantumMPC_GRAPE(
        t_end=5.0,
        T=100,      # Time steps
        L=15,       # Prediction horizon
        m=1,        # Control steps per iteration
        max_iter=30, # GRAPE iterations
        learning_rate=0.15
    )
    
    # Run MPC
    try:
        total_time = mpc.run_mpc()
        
        # Plot results
        mpc.plot_results()
        
        # Performance analysis
        mpc.analyze_performance()
        
    except Exception as e:
        print(f"Error occurred: {e}")
        print("Trying with simpler parameters...")
        
        # Fallback to simpler parameters
        mpc_simple = QuantumMPC_GRAPE(
            t_end=5.0,
            T=50,       # Fewer time steps
            L=8,        # Shorter horizon
            m=3,        # Smaller control steps
            max_iter=20, # Fewer iterations
            learning_rate=0.1
        )
        
        total_time = mpc_simple.run_mpc()
        mpc_simple.plot_results()
        mpc_simple.analyze_performance()