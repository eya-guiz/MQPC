# -*- coding: utf-8 -*-
"""
Created on Fri Sep  5 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Benchmark_AllSchemes_rho.py

Single script to run and compare three MPC formulations for the 2-level density-matrix system:
  1) Unconstrained moving-horizon MPC
  2) TEC-style constrained MPC (terminal-equality on window end)
  3) Tracking MPC (steady-state xs, us with terminal equality + steady-state constraints)

For each scheme the script:
  - sweeps prediction horizon L in L_values
  - measures cumulative MPC solver runtime (sum of window solves)
  - evaluates a uniform closed-loop cost on the assembled control sequence
  - solves the full-horizon variant (same cost and constraints) as baseline

Outputs a comprehensive figure with Cost vs L and Runtime vs L for all three schemes
and prints summary statistics.

Dependencies: numpy, casadi, qutip, scipy, matplotlib
"""

import time
import numpy as np
import casadi as ca
import matplotlib.pyplot as plt
from qutip import basis, ket2dm, Qobj
from scipy.linalg import expm
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# ========================= Time & MPC parameters ========================= #
t_end = 2.0
T = 40
m =2
L_values = list(range(1, 21))

dt = t_end / T
full_tlist = np.linspace(0.0, t_end, T)

# ============================ System parameters ========================= #
nb_inputs = 2
omega = 1.0
ampl0 = [0.2, 0.2]

# Pauli matrices
SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)

H0 = omega * SZ
H_controls = [SX, SY]

# ====================== Initial & target quantum states ================== #
psi0 = basis(2, 0)
psi_ref = basis(2, 1)

# ==================== Density matrix real-vector conversion ============== #
dim = 2
Nmat = dim * dim

H_list = [H0] + H_controls
H_real = [np.real(H).astype(float) for H in H_list]
H_imag = [np.imag(H).astype(float) for H in H_list]

def rho_to_real_vec(rho_qobj):
    rho = np.asarray(rho_qobj.full())
    A = np.real(rho)
    B = np.imag(rho)
    return np.concatenate([A.flatten(), B.flatten()]).astype(float)

x0_np = rho_to_real_vec(ket2dm(psi0))
xref_np = rho_to_real_vec(ket2dm(psi_ref))

# ====================== CasADi symbolic model (RK4) ====================== #
x = ca.MX.sym('x', 2 * Nmat)
u = ca.MX.sym('u', nb_inputs)

Hr = ca.DM(H_real[0]) + u[0] * ca.DM(H_real[1]) + u[1] * ca.DM(H_real[2])
Hi = ca.DM(H_imag[0]) + u[0] * ca.DM(H_imag[1]) + u[1] * ca.DM(H_imag[2])

A = ca.reshape(x[:Nmat], (dim, dim))
B = ca.reshape(x[Nmat:], (dim, dim))

dA = Hr @ B + Hi @ A - B @ Hr - A @ Hi
dB = -Hr @ A + Hi @ B + A @ Hr - B @ Hi

xdot = ca.vertcat(ca.reshape(dA, Nmat, 1), ca.reshape(dB, Nmat, 1))
xdot_fun = ca.Function('xdot_fun', [x, u], [xdot])

# RK4 integrator (built once)
def _rk4(xk, uk, h):
    k1 = xdot_fun(xk, uk)
    k2 = xdot_fun(xk + 0.5 * h * k1, uk)
    k3 = xdot_fun(xk + 0.5 * h * k2, uk)
    k4 = xdot_fun(xk + h * k3, uk)
    return xk + (h / 6.0) * (k1 + 2 * k2 + 2 * k3 + k4)

step_fun = ca.Function('step_fun', [x, u], [_rk4(x, u, dt)])

# Fidelity helpers
Ar_sym = ca.reshape(ca.DM(xref_np[:Nmat]), (dim, dim))
Br_sym = ca.reshape(ca.DM(xref_np[Nmat:]), (dim, dim))

def fidelity_from_x(xv):
    A = ca.reshape(xv[:Nmat], (dim, dim))
    B = ca.reshape(xv[Nmat:], (dim, dim))
    return ca.trace(Ar_sym @ A + Br_sym @ B)


def fidelity_between(x1, x2):
    A1 = ca.reshape(x1[:Nmat], (dim, dim))
    B1 = ca.reshape(x1[Nmat:], (dim, dim))
    A2 = ca.reshape(x2[:Nmat], (dim, dim))
    B2 = ca.reshape(x2[Nmat:], (dim, dim))
    return ca.trace(A2 @ A1 + B2 @ B1)

# =========================== Cost settings =============================== #
lambda_u = 1e-4
lambda_x = 1.0
# tracking MPC weights
lambda_xs = 100.0
lambda_us = 1.0

u_ref = np.array([0.0, 0.0], dtype=float)
u_ref_dm = ca.DM(u_ref)

# Unified evaluation cost on closed-loop rollout (same for all schemes)
def evaluate_total_cost_from_controls(U_controls):
    xk = ca.DM(x0_np)
    J = 0.0
    for k in range(T):
        uk = ca.DM(U_controls[:, k])
        xk = step_fun(xk, uk)
        J += float(lambda_u * ca.sumsqr(uk - u_ref_dm))
        J += float(lambda_x * (1.0 - fidelity_from_x(xk)))
    return J

# IPOPT options
nlp_opts = {
    'ipopt.print_level': 0,
    'ipopt.max_iter': 150,
    'ipopt.tol': 1e-6,
    'ipopt.linear_solver': 'mumps',
    'print_time': 0,
}

# ======================= Unconstrained MPC + Full-Horizon ==================

def run_mpc_unconstrained(L):
    runtime_table = []
    mpc_control = np.zeros((nb_inputs, T), dtype=float)
    U_prev_window = None

    current_x = x0_np.copy()

    n_steps = int(np.ceil(T / m))
    for step_idx in range(n_steps):
        t_idx = step_idx * m
        if t_idx >= T:
            break
        window_end = min(t_idx + L, T)
        Nw = window_end - t_idx
        apply_steps = min(m, Nw)

        U = ca.MX.sym('U', nb_inputs, Nw)
        xk = ca.DM(current_x)
        J = 0
        for k in range(Nw):
            uk = U[:, k]
            xk = step_fun(xk, uk)
            J += lambda_u * ca.sumsqr(uk - u_ref_dm)
            J += lambda_x * (1.0 - fidelity_from_x(xk))

        nlp = {'x': ca.vec(U), 'f': J}
        solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

        lbw = np.full(nb_inputs * Nw, -1.0)
        ubw = np.full(nb_inputs * Nw, 1.0)

        # warm start
        if U_prev_window is None:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, Nw))
        else:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                tail = U_prev_window[i, apply_steps:]
                n_fill = min(tail.shape[0], Nw)
                guess[i, :n_fill] = tail[:n_fill]

        x0_guess = ca.vec(ca.DM(guess)).full()
        start = time.time()
        sol = ca.nlpsol('solver', 'ipopt', {'x': ca.vec(U), 'f': J}, nlp_opts)
        # NOTE: to avoid rebuilding solver twice we call solver directly below
        sol = ca.nlpsol('solver', 'ipopt', {'x': ca.vec(U), 'f': J}, nlp_opts)
        # but actually use solver as above
        sol = ca.nlpsol('solver', 'ipopt', {'x': ca.vec(U), 'f': J}, nlp_opts).solve if False else None
        # The above double-construction is wasteful; instead we'll just construct solver once and use it.
        solver = ca.nlpsol('solver', 'ipopt', {'x': ca.vec(U), 'f': J}, nlp_opts)
        start = time.time()
        sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw)
        elapsed = time.time() - start
        runtime_table.append(elapsed)

        U_win = np.array(sol['x']).reshape((nb_inputs, Nw), order='F')
        U_prev_window = U_win.copy()

        for i in range(nb_inputs):
            mpc_control[i, t_idx:t_idx + apply_steps] = U_win[i, :apply_steps]

        for local in range(apply_steps):
            uk_apply = ca.DM(mpc_control[:, t_idx + local])
            current_x = np.array(step_fun(ca.DM(current_x), uk_apply)).reshape(-1)

    total_runtime = float(np.sum(runtime_table))
    return total_runtime, mpc_control


def run_full_unconstrained():
    N = T
    U = ca.MX.sym('U', nb_inputs, N)
    xk = ca.DM(x0_np)
    J = 0
    for k in range(N):
        uk = U[:, k]
        xk = step_fun(xk, uk)
        J += lambda_u * ca.sumsqr(uk - u_ref_dm)
        J += lambda_x * (1.0 - fidelity_from_x(xk))

    nlp = {'x': ca.vec(U), 'f': J}
    solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)
    lbw = np.full(nb_inputs * N, -1.0)
    ubw = np.full(nb_inputs * N, 1.0)

    warm_init = np.zeros((nb_inputs, N))
    for i in range(nb_inputs):
        warm_init[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, N))
    x0_guess = ca.vec(ca.DM(warm_init)).full()

    start = time.time()
    sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw)
    elapsed = time.time() - start
    U_opt = np.array(sol['x']).reshape((nb_inputs, N), order='F')
    return elapsed, U_opt

# ====================== TEC-constrained MPC + Full-Horizon ==============

def run_mpc_TEC(L):
    runtime_table = []
    mpc_control = np.zeros((nb_inputs, T), dtype=float)
    U_prev_window = None
    current_x = x0_np.copy()

    n_steps = int(np.ceil(T / m))
    for step_idx in range(n_steps):
        t_idx = step_idx * m
        if t_idx >= T:
            break
        window_end = min(t_idx + L, T)
        Nw = window_end - t_idx
        apply_steps = min(m, Nw)

        U = ca.MX.sym('U', nb_inputs, Nw)
        xk = ca.DM(current_x)
        J = 0
        for k in range(Nw):
            uk = U[:, k]
            xk = step_fun(xk, uk)
            J += lambda_u * ca.sumsqr(uk - u_ref_dm)
            J += lambda_x * (1.0 - fidelity_from_x(xk))

        g = 1.0 - fidelity_from_x(xk)
        nlp = {'x': ca.vec(U), 'f': J, 'g': g}
        solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

        lbw = np.full(nb_inputs * Nw, -1.0)
        ubw = np.full(nb_inputs * Nw, 1.0)
        lbg = np.zeros(1)
        ubg = np.zeros(1)

        if U_prev_window is None:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, Nw))
        else:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                tail = U_prev_window[i, apply_steps:]
                n_fill = min(tail.shape[0], Nw)
                guess[i, :n_fill] = tail[:n_fill]

        x0_guess = ca.vec(ca.DM(guess)).full()
        start = time.time()
        sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
        elapsed = time.time() - start
        runtime_table.append(elapsed)

        U_win = np.array(sol['x']).reshape((nb_inputs, Nw), order='F')
        U_prev_window = U_win.copy()

        for i in range(nb_inputs):
            mpc_control[i, t_idx:t_idx + apply_steps] = U_win[i, :apply_steps]

        for local in range(apply_steps):
            uk_apply = ca.DM(mpc_control[:, t_idx + local])
            current_x = np.array(step_fun(ca.DM(current_x), uk_apply)).reshape(-1)

    total_runtime = float(np.sum(runtime_table))
    return total_runtime, mpc_control


def run_full_TEC():
    N = T
    U = ca.MX.sym('U', nb_inputs, N)
    xk = ca.DM(x0_np)
    J = 0
    for k in range(N):
        uk = U[:, k]
        xk = step_fun(xk, uk)
        J += lambda_u * ca.sumsqr(uk - u_ref_dm)
        J += lambda_x * (1.0 - fidelity_from_x(xk))

    g = 1.0 - fidelity_from_x(xk)
    nlp = {'x': ca.vec(U), 'f': J, 'g': g}
    solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

    lbw = np.full(nb_inputs * N, -1.0)
    ubw = np.full(nb_inputs * N, 1.0)
    lbg = np.zeros(1)
    ubg = np.zeros(1)

    warm_init = np.zeros((nb_inputs, N))
    for i in range(nb_inputs):
        warm_init[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, N))
    x0_guess = ca.vec(ca.DM(warm_init)).full()

    start = time.time()
    sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
    elapsed = time.time() - start
    U_opt = np.array(sol['x']).reshape((nb_inputs, N), order='F')
    return elapsed, U_opt

# ====================== Tracking MPC + Full-Horizon ======================

def run_mpc_tracking(L):
    runtime_table = []
    mpc_control = np.zeros((nb_inputs, T), dtype=float)
    U_prev_window = None

    current_x = x0_np.copy()

    xs_history = []
    us_history = []

    n_steps = int(np.ceil(T / m))
    for step_idx in range(n_steps):
        t_idx = step_idx * m
        if t_idx >= T:
            break
        window_end = min(t_idx + L, T)
        Nw = window_end - t_idx
        apply_steps = min(m, Nw)

        U = ca.MX.sym('U', nb_inputs, Nw)
        xs = ca.MX.sym('xs', 2 * Nmat)
        us = ca.MX.sym('us', nb_inputs)
        X = ca.vertcat(ca.vec(U), xs, us)

        xk = ca.DM(current_x)
        J = 0
        for k in range(Nw):
            uk = U[:, k]
            J += lambda_u * ca.sumsqr(uk - u_ref_dm)
            xk = step_fun(xk, uk)
            J += lambda_x * (1.0 - fidelity_between(xk, xs))

        J += lambda_xs * (1.0 - fidelity_from_x(xs))
        J += lambda_us * ca.sumsqr(us - u_ref_dm)
        J += 1e-8 * (ca.sumsqr(xs) + ca.sumsqr(us))

        g_terminal = xk - xs
        g_steady = xdot_fun(xs, us)
        Axs = ca.reshape(xs[:Nmat], (dim, dim))
        Bxs = ca.reshape(xs[Nmat:], (dim, dim))
        g_trace = ca.trace(Axs) - 1.0
        g_herm_a = Axs[0, 1] - Axs[1, 0]
        g_herm_b = Bxs[0, 1] + Bxs[1, 0]

        g = ca.vertcat(g_terminal, g_steady, g_trace, g_herm_a, g_herm_b)

        nlp = {'x': X, 'f': J, 'g': g}
        solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

        nv = nb_inputs * Nw + 2 * Nmat + nb_inputs
        lbw = -ca.inf * ca.DM.ones(nv, 1)
        ubw = ca.inf * ca.DM.ones(nv, 1)
        lbw[:nb_inputs * Nw] = -1.0
        ubw[:nb_inputs * Nw] = 1.0
        offset_us = nb_inputs * Nw + 2 * Nmat
        lbw[offset_us:offset_us + nb_inputs] = -1.0
        ubw[offset_us:offset_us + nb_inputs] = 1.0

        lbg = ca.DM.zeros(g.shape[0])
        ubg = ca.DM.zeros(g.shape[0])

        if U_prev_window is None:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, Nw))
        else:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                tail = U_prev_window[i, apply_steps:]
                n_fill = min(tail.shape[0], Nw)
                guess[i, :n_fill] = tail[:n_fill]

        x0_guess = ca.vertcat(ca.vec(ca.DM(guess)), ca.DM(current_x), ca.DM(guess[:, -1]))
        x0_guess[-2 * Nmat - nb_inputs: -nb_inputs] = xref_np
        x0_guess[-nb_inputs:] = u_ref

        start = time.time()
        sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
        elapsed = time.time() - start
        runtime_table.append(elapsed)

        X_opt = np.array(sol['x']).reshape((-1,))
        U_opt = X_opt[: nb_inputs * Nw].reshape((nb_inputs, Nw), order='F')
        xs_opt = X_opt[nb_inputs * Nw: nb_inputs * Nw + 2 * Nmat]
        us_opt = X_opt[nb_inputs * Nw + 2 * Nmat:]

        xs_history.append(xs_opt)
        us_history.append(us_opt)

        for i in range(nb_inputs):
            mpc_control[i, t_idx:t_idx + apply_steps] = U_opt[i, :apply_steps]

        for local in range(apply_steps):
            uk_apply = ca.DM(mpc_control[:, t_idx + local])
            current_x = np.array(step_fun(ca.DM(current_x), uk_apply)).reshape(-1)

        U_prev_window = U_opt.copy()

    total_runtime = float(np.sum(runtime_table))
    return total_runtime, mpc_control


def run_full_tracking():
    N = T
    U = ca.MX.sym('U', nb_inputs, N)
    xs = ca.MX.sym('xs', 2 * Nmat)
    us = ca.MX.sym('us', nb_inputs)

    xk = ca.DM(x0_np)
    J = 0
    for k in range(N):
        uk = U[:, k]
        xk = step_fun(xk, uk)
        J += lambda_u * ca.sumsqr(uk - u_ref_dm)
        J += lambda_x * (1.0 - fidelity_between(xk, xs))

    J += lambda_xs * (1.0 - fidelity_from_x(xs))
    J += lambda_us * ca.sumsqr(us - u_ref_dm)

    g_steady = xdot_fun(xs, us)
    Axs = ca.reshape(xs[:Nmat], (dim, dim))
    Bxs = ca.reshape(xs[Nmat:], (dim, dim))
    g_trace = ca.trace(Axs) - 1.0
    g_herm_a = Axs[0, 1] - Axs[1, 0]
    g_herm_b = Bxs[0, 1] + Bxs[1, 0]

    g = ca.vertcat(g_steady, g_trace, g_herm_a, g_herm_b)

    nlp = {'x': ca.vertcat(ca.vec(U), xs, us), 'f': J, 'g': g}
    solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

    nv = nb_inputs * N + 2 * Nmat + nb_inputs
    lbw = -ca.inf * ca.DM.ones(nv, 1)
    ubw = ca.inf * ca.DM.ones(nv, 1)
    lbw[:nb_inputs * N] = -1.0
    ubw[:nb_inputs * N] = 1.0
    offset_us = nb_inputs * N + 2 * Nmat
    lbw[offset_us:offset_us + nb_inputs] = -1.0
    ubw[offset_us:offset_us + nb_inputs] = 1.0

    lbg = ca.DM.zeros(g.shape[0])
    ubg = ca.DM.zeros(g.shape[0])

    warm_init = np.zeros((nb_inputs, N))
    for i in range(nb_inputs):
        warm_init[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, N))
    x0_guess = ca.vertcat(ca.vec(ca.DM(warm_init)), ca.DM(xref_np), ca.DM(u_ref))

    start = time.time()
    sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
    elapsed = time.time() - start
    X_opt = np.array(sol['x']).reshape((-1,))
    U_opt = X_opt[: nb_inputs * N].reshape((nb_inputs, N), order='F')
    return elapsed, U_opt

# ============================= Benchmark Loop =========================== #

schemes = ['unconstrained', 'TEC', 'tracking']
results = {s: {'costs': [], 'times': []} for s in schemes}
full_baselines = {}

print("Starting full-horizon baselines...")
full_baselines['unconstrained'] = run_full_unconstrained()
print(f"Full unconstrained runtime: {full_baselines['unconstrained'][0]:.2f}s")
full_baselines['TEC'] = run_full_TEC()
print(f"Full TEC runtime: {full_baselines['TEC'][0]:.2f}s")
full_baselines['tracking'] = run_full_tracking()
print(f"Full tracking runtime: {full_baselines['tracking'][0]:.2f}s")

# Extract full-horizon costs
full_costs = {}
for key in schemes:
    full_runtime, U_full = full_baselines[key]
    full_costs[key] = evaluate_total_cost_from_controls(U_full)
    print(f"Full-horizon {key} cost: {full_costs[key]:.6e}, runtime: {full_runtime:.2f}s")

# Run MPC sweeps
for L in L_values:
    print(f"\nSweep L = {L}")
    rt_u, ctrl_u = run_mpc_unconstrained(L)
    cost_u = evaluate_total_cost_from_controls(ctrl_u)
    results['unconstrained']['times'].append(rt_u)
    results['unconstrained']['costs'].append(cost_u)
    print(f" unconstrained: cost={cost_u:.6e}, time={rt_u:.2f}s")

    rt_tec, ctrl_tec = run_mpc_TEC(L)
    cost_tec = evaluate_total_cost_from_controls(ctrl_tec)
    results['TEC']['times'].append(rt_tec)
    results['TEC']['costs'].append(cost_tec)
    print(f" TEC: cost={cost_tec:.6e}, time={rt_tec:.2f}s")

    rt_tr, ctrl_tr = run_mpc_tracking(L)
    cost_tr = evaluate_total_cost_from_controls(ctrl_tr)
    results['tracking']['times'].append(rt_tr)
    results['tracking']['costs'].append(cost_tr)
    print(f" tracking: cost={cost_tr:.6e}, time={rt_tr:.2f}s")

# ========================= Plot Cost & Runtime (comprehensive) ==========
fig, (ax_cost, ax_time) = plt.subplots(2, 1, figsize=(10, 14), sharex=True)

# cost curves
ax_cost.plot(L_values, results['unconstrained']['costs'], 'o-', label='Basic MPQC')
ax_cost.plot(L_values, results['TEC']['costs'], 's-', label=' TEC MPQC')
ax_cost.plot(L_values, results['tracking']['costs'], 'd-', label='Setpoint Tracking MPQC')
# full-horizon baselines
ax_cost.axhline(full_costs['unconstrained'], linestyle='--', color='black', label='QOC')
#ax_cost.axhline(full_costs['TEC'], linestyle='--', color='black', label='QOC')
#ax_cost.axhline(full_costs['tracking'], linestyle='--', color='black', label='Full Tracking')

ax_cost.set_ylabel('Total Cost', fontsize = 20)
ax_cost.set_title('(a)', fontsize = 20, loc = 'left')
ax_cost.grid(which='both', linestyle='--', alpha=0.6)
#ax_cost.tick_params(axis='x', labelsize=10) 
ax_cost.tick_params(axis='y', labelsize=15)
ax_cost.legend(loc='upper right', fontsize=13)
# runtime curves

ax_time.plot(L_values, results['unconstrained']['times'], 'o-', label='Basic MPQC')
ax_time.plot(L_values, results['TEC']['times'], 's-', label=' TEC MPQC')
ax_time.plot(L_values, results['tracking']['times'], 'd-', label='Setpoint Tracking MPQC')
ax_time.axhline(full_baselines['unconstrained'][0], linestyle='--', color='black', label='QOC')
#ax_time.axhline(full_baselines['TEC'][0], linestyle='--', color='black', label='QOC')
#ax_time.axhline(full_baselines['tracking'][0], linestyle='--', color='C2', label='Full Tracking')

ax_time.set_xlabel('Prediction Horizon L', fontsize = 20)
ax_time.set_ylabel('MPQC Runtime [s]', fontsize = 20)
ax_time.set_title('(b)', fontsize = 20, loc = 'left')
ax_time.grid(which='both', linestyle='--', alpha=0.6)
#ax_time.tick_params(axis='x', labelsize=10) 
ax_time.tick_params(axis='y', labelsize=15)
#ax_time.legend(loc='upper right', fontsize=13)

# Add zoomed inset for runtime tail until L=12
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset

#axins = inset_axes(ax_time, width="50%", height="40%", loc='upper left')
axins = inset_axes(
    ax_time,
    width="50%", height="40%",
    loc='upper left',
    bbox_to_anchor=(0.05, 0, 1, 1),  # shift right: increase first number
    bbox_transform=ax_time.transAxes,
    borderpad=0
)

# plot the same runtime curves inside the inset
axins.plot(L_values[:9], results['unconstrained']['times'][:9], 'o-', color='tab:blue')
axins.plot(L_values[:9], results['TEC']['times'][:9], 's-', color='tab:orange')
axins.plot(L_values[:9], results['tracking']['times'][:9], 'd-', color='tab:green')
axins.axhline(full_baselines['unconstrained'][0], linestyle='--', color='black', label='QOC')
axins.tick_params(axis='both', which='major', labelsize=13)
axins.grid(which='both', linestyle='--', alpha=0.6)
plt.xticks(L_values[:9])
plt.tight_layout()
plt.show()


# Force integer ticks for horizon axis on bottom
ax_time.set_xticks(L_values)
ax_time.set_xticklabels(L_values, fontsize=15)  # bottom ticks size

# Make top plot x-axis ticks visible and set size
ax_cost.tick_params(axis='x', which='both', labelbottom=True, labelsize=15)


# Print summary table
print('\nSummary (last line):')
for s in schemes:
    print(f"{s}: min cost={np.min(results[s]['costs']):.6e}, min runtime={np.min(results[s]['times']):.3f}s")

print('\nDone.')
