# -*- coding: utf-8 -*-
"""
Created on Fri Sep  5 11:36:39 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Benchmark (TEC-style, CONSTRAINED) CasADi MPC for a closed 2‑level quantum system
- Same plant representation as the TEC script (density matrix with real/imag split).
- Enforces the TEC terminal equality constraint on the prediction window end:
    g = 1 - Fidelity(x_N) == 0  (i.e. enforce fidelity==1 at window horizon)
- Varies prediction horizon L and measures (i) closed-loop total cost & (ii) cumulative solver runtime.
- Compares to a full-horizon constrained optimal control (terminal equality at final timestep).

Notes
-----
• All CasADi functions (xdot_fun, step_fun, fidelity_from_x) are built once.
• Solver options tuned for stability (IPOPT + mumps), matching TEC choices.
• Inputs remain bounded: u in [-1, 1].

Run this file to reproduce the TEC-style constrained benchmark.
"""

import time
import numpy as np
import casadi as ca
import matplotlib.pyplot as plt
from qutip import basis, ket2dm, Qobj
from scipy.linalg import expm
from mpl_toolkits.axes_grid1.inset_locator import inset_axes

# ========================= Time & MPC parameters ========================= #
t_end = 2.0
T = 40
m = 2
L_values = [1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20]

dt = t_end / T
full_tlist = np.linspace(0.0, t_end, T)

# ============================ System parameters ========================= #
nb_inputs = 2
omega = 1.0
ampl0 = [0.2, 0.2]

# Pauli (complex numpy)
SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)

H0 = omega * SZ
H_controls = [SX, SY]

# ====================== Initial & target quantum states ================== #
psi0 = basis(2, 0)
psi_ref = basis(2, 1)

# ==================== Density matrix real-vector conversion ============== #
dim = 2
Nmat = dim*dim

H_list = [H0] + H_controls
H_real = [np.real(H).astype(float) for H in H_list]
H_imag = [np.imag(H).astype(float) for H in H_list]

def rho_to_real_vec(rho_qobj):
    rho = np.asarray(rho_qobj.full())
    A = np.real(rho)
    B = np.imag(rho)
    return np.concatenate([A.flatten(), B.flatten()]).astype(float)

x0_np   = rho_to_real_vec(ket2dm(psi0))
xref_np = rho_to_real_vec(ket2dm(psi_ref))

# ====================== CasADi symbolic model (RK4) ====================== #
x = ca.MX.sym('x', 2*Nmat)
u = ca.MX.sym('u', nb_inputs)

Hr = ca.DM(H_real[0]) + u[0]*ca.DM(H_real[1]) + u[1]*ca.DM(H_real[2])
Hi = ca.DM(H_imag[0]) + u[0]*ca.DM(H_imag[1]) + u[1]*ca.DM(H_imag[2])

A = ca.reshape(x[:Nmat], (dim, dim))
B = ca.reshape(x[Nmat:], (dim, dim))

dA = Hr@B + Hi@A - B@Hr - A@Hi
dB = -Hr@A + Hi@B + A@Hr - B@Hi

xdot = ca.vertcat(ca.reshape(dA, Nmat, 1), ca.reshape(dB, Nmat, 1))
xdot_fun = ca.Function('xdot_fun', [x, u], [xdot])

# RK4 integrator

def _rk4(xk, uk, h):
    k1 = xdot_fun(xk, uk)
    k2 = xdot_fun(xk + 0.5*h*k1, uk)
    k3 = xdot_fun(xk + 0.5*h*k2, uk)
    k4 = xdot_fun(xk + h*k3, uk)
    return xk + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)

step_fun = ca.Function('step_fun', [x, u], [_rk4(x, u, dt)])

# Fidelity (trace with reference density)
Ar = ca.reshape(ca.DM(xref_np[:Nmat]), (dim, dim))
Br = ca.reshape(ca.DM(xref_np[Nmat:]), (dim, dim))

def fidelity_from_x(xv):
    A = ca.reshape(xv[:Nmat], (dim, dim))
    B = ca.reshape(xv[Nmat:], (dim, dim))
    return ca.trace(Ar @ A + Br @ B)

# =========================== Cost settings =============================== #
lambda_u = 1e-4
lambda_x = 1.0
u_ref_dm = ca.DM([0.0, 0.0])

# Unified cost evaluation (closed-loop rollout)

def evaluate_total_cost_from_controls(U_controls):
    xk = ca.DM(x0_np)
    J = 0.0
    for k in range(T):
        uk = ca.DM(U_controls[:, k])
        xk = step_fun(xk, uk)
        J += float(lambda_u * ca.sumsqr(uk - u_ref_dm))
        J += float(lambda_x * (1.0 - fidelity_from_x(xk)))
    return J

# =========================== IPOPT options =============================== #
nlp_opts = {
    'ipopt.print_level': 0,
    'ipopt.max_iter': 150,
    'ipopt.tol': 1e-6,
    'ipopt.linear_solver': 'mumps',
    'print_time': 0,
}

# =================== Full-horizon TEC constrained optimal control ======= #
def run_full_horizon_constrained():
    N = T
    U = ca.MX.sym('U', nb_inputs, N)

    xk = ca.DM(x0_np)
    J = 0
    for k in range(N):
        uk = U[:, k]
        xk = step_fun(xk, uk)
        J += lambda_u * ca.sumsqr(uk - u_ref_dm)
        J += lambda_x * (1.0 - fidelity_from_x(xk))

    # Terminal equality: fidelity(x_N) == 1  -> g = 1 - fidelity(x_N) == 0
    g = 1.0 - fidelity_from_x(xk)

    nlp = {'x': ca.vec(U), 'f': J, 'g': g}
    solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

    lbw = np.full(nb_inputs*N, -1.0)
    ubw = np.full(nb_inputs*N, 1.0)
    lbg = np.zeros(1)
    ubg = np.zeros(1)

    warm_init = np.array([
        0.2*np.sin(np.linspace(0, np.pi, N)),
        0.2*np.cos(np.linspace(0, np.pi, N)),
    ])
    x0_guess = warm_init.flatten(order='F')

    start_step = time.time()
    sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
    elapsed = time.time() - start_step

    U_opt = np.array(sol['x']).reshape((nb_inputs, N), order='F')
    return elapsed, U_opt

# ======================= MPC (TEC-style constrained) ==================== #

def run_mpc_tec_constrained(L):
    runtime_table = []
    mpc_control = np.zeros((nb_inputs, T), dtype=float)
    U_prev_window = None
    current_x = x0_np.copy()

    n_steps = int(np.ceil(T / m))
    for step_idx in range(n_steps):
        t_idx = step_idx * m
        if t_idx >= T:
            break
        window_end = min(t_idx + L, T)
        Nw = window_end - t_idx
        apply_steps = min(m, Nw)

        U = ca.MX.sym('U', nb_inputs, Nw)

        xk = ca.DM(current_x)
        J = 0
        for k in range(Nw):
            uk = U[:, k]
            xk = step_fun(xk, uk)
            J += lambda_u * ca.sumsqr(uk - u_ref_dm)
            J += lambda_x * (1.0 - fidelity_from_x(xk))

        # TEC terminal equality on the window end
        g = 1.0 - fidelity_from_x(xk)

        nlp = {'x': ca.vec(U), 'f': J, 'g': g}
        solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

        lbw = np.full(nb_inputs*Nw, -1.0)
        ubw = np.full(nb_inputs*Nw, 1.0)
        lbg = np.zeros(1)
        ubg = np.zeros(1)

        # Warm start
        if U_prev_window is None:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, Nw))
        else:
            guess = np.zeros((nb_inputs, Nw), dtype=float)
            for i in range(nb_inputs):
                tail = U_prev_window[i, apply_steps:]
                n_fill = min(tail.shape[0], Nw)
                guess[i, :n_fill] = tail[:n_fill]

        x0_guess = ca.vec(ca.DM(guess)).full()

        start_step = time.time()
        sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
        elapsed = time.time() - start_step
        runtime_table.append(elapsed)

        U_win = np.array(sol['x']).reshape((nb_inputs, Nw), order='F')
        U_prev_window = U_win.copy()

        for i in range(nb_inputs):
            mpc_control[i, t_idx:t_idx+apply_steps] = U_win[i, :apply_steps]

        # Update current_x for warm-start physics only
        for local in range(apply_steps):
            uk_apply = ca.DM(mpc_control[:, t_idx + local])
            current_x = np.array(step_fun(ca.DM(current_x), uk_apply)).reshape(-1)

    total_runtime = float(np.sum(runtime_table))
    return total_runtime, mpc_control

# ============================= Benchmark Loop =========================== #
costs = []
times = []

print("=== TEC-style CONSTRAINED MPC vs Full-horizon CONSTRAINED OC ===")
for L_test in L_values:
    print(f"Running TEC-constrained MPC with L = {L_test}")
    total_runtime_mpc_L, mpc_control_L = run_mpc_tec_constrained(L_test)

    total_cost_closed_loop_L = evaluate_total_cost_from_controls(mpc_control_L)

    costs.append(total_cost_closed_loop_L)
    times.append(total_runtime_mpc_L)
    print(f" -> Total Cost: {total_cost_closed_loop_L:.6e}, Runtime: {total_runtime_mpc_L:.2f}s")

# Full-horizon constrained solve
print("Solving full-horizon constrained optimal control ...")
full_runtime, U_opt = run_full_horizon_constrained()
full_cost = evaluate_total_cost_from_controls(U_opt)
print(f" -> Full-horizon Cost: {full_cost:.6e}, Runtime: {full_runtime:.2f}s")

import matplotlib.ticker as mticker
from mpl_toolkits.axes_grid1.inset_locator import inset_axes, mark_inset

# Create figure with two subplots
fig, (ax_cost, ax_runtime) = plt.subplots(2, 1, figsize=(10, 14))

# ----------- Cost Plot -----------
ax_cost.plot(L_values, costs, 's--', color='tab:blue', label='TEC MPQC')
ax_cost.axhline(full_cost, color='black', linestyle='--', label='TEC QOC')
ax_cost.set_xlabel('Prediction Horizon L', fontsize=20)
ax_cost.set_ylabel('Total Cost', fontsize = 20)
ax_cost.set_title('(a)', fontsize = 20, loc = 'left')
ax_cost.tick_params(axis='y', labelsize=15)
ax_cost.legend(loc='upper right', fontsize=13)
ax_cost.set_xticks(L_values)
ax_cost.grid(which='both', linestyle='--', alpha=0.7)
ax_cost.legend(fontsize=20)

# # Inset for tail zoom
# axins = inset_axes(ax_cost, width="45%", height="30%", loc='right')
# tail_start = 9
# tail_costs = costs[tail_start:]
# tail_L = L_values[tail_start:]
# # Scale for visualization
# tail_costs_scaled = [c * 1e5 for c in tail_costs]
# axins.plot(tail_L, tail_costs_scaled, 's--', color='tab:blue')
# axins.axhline(total_cost_T, color='blue', linestyle='--')
# axins.set_xticks(tail_L)
# # Labels & formatting
# axins.set_title('Zoomed-in tail (x1e-5)', fontsize=9)
# #axins.set_xlabel('L', fontsize=8)
# #axins.set_ylabel('Total Cost', fontsize=8)
# axins.tick_params(axis='both', which='major', labelsize=8)
# axins.grid(True)
# # Horizontal padding
# x_pad = 0.5  # in L units
# axins.set_xlim(tail_L[0] - x_pad, tail_L[-1] + x_pad)
# # Vertical padding
# y_min = min(tail_costs_scaled)
# y_max = max(tail_costs_scaled)
# y_pad = 0.05 * (y_max - y_min)  # 5% of range
# axins.set_ylim(y_min - y_pad, y_max + y_pad)
# axins.grid(which='both', linestyle='--', alpha=0.7)

# #mark_inset(ax_cost, axins, loc1=2, loc2=4, fc="none", ec="0.5")

# ----------- Runtime Plot -----------
ax_runtime.plot(L_values, times, 's--', color='tab:blue', label='TEC MPQC')
ax_runtime.axhline(full_runtime, color='black', linestyle='--', label='TEC QOC')
ax_runtime.set_xlabel('Prediction Horizon L', fontsize = 20)
ax_runtime.set_ylabel('Runtime[s]', fontsize = 20)
#ax_runtime.set_title('Runtime vs MPC Horizon')
ax_runtime.legend()
ax_runtime.grid(which='both', linestyle='--', alpha=0.7)
ax_runtime.set_title('(b)', fontsize = 20, loc = 'left')
ax_runtime.tick_params(axis='y', labelsize=15)
ax_runtime.legend(fontsize=20)

# Force integer ticks for horizon axis on bottom
ax_runtime.set_xticks(L_values)
ax_runtime.set_xticklabels(L_values, fontsize=15)  # bottom ticks size

# Make top plot x-axis ticks visible and set size
ax_cost.tick_params(axis='x', which='both', labelbottom=True, labelsize=15)

plt.tight_layout()
plt.show()


