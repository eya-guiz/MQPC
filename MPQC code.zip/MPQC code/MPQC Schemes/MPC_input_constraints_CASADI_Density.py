# -*- coding: utf-8 -*-
"""
Stable CasADi MPC for a closed 2-level quantum system (Windows-friendly)
- Uses real-valued state split (Re, Im).
- Single-shooting NLP with RK4 integrator.
- Bounded inputs u in [-1, 1].
- Adds light regularization and IPOPT settings that reduce memory pressure.
- Avoids mixing complex arrays with CasADi.

Tested design choices to prevent kernel crashes:
  • Build ALL CasADi Functions ONCE (outside the MPC loop).
  • Keep CasADi strictly real; do not pass complex arrays into CasADi.
  • Use IPOPT with 'mumps' linear solver and conservative iteration caps.
  • Create the solver each iteration (N can vary) but with small N.
"""

import numpy as np
import casadi as ca
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import basis, sigmax, sigmay, sigmaz, ket2dm, fidelity, Qobj
import time

# ========================= Time & MPC parameters ========================= #
t_end = 5.0
T = 100
dt = t_end / T
full_tlist = np.linspace(0.0, t_end, T)

L = 3        # prediction horizon (steps) – keep modest on Windows
m = 1         # apply steps per MPC iteration
nb_opts = int(np.ceil(T / m))

# ============================ System parameters ========================= #
nb_inputs = 2
omega = 1.0
ampl0 = [0.2, 0.2]

# Pauli (complex numpy)
SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)

H0 = omega * SZ
H_controls = [SX, SY]

# ====================== Initial & target quantum states ================== #
psi0 = basis(2, 0)  # |0>
#psi_ref = basis(2, 1)
psi_ref = (basis(2,0) + basis(2,1)).unit()

# Reference input
r_vec = np.array([0.0, 0.0, 1.0])
xr, yr, zr = r_vec
u1_ref = 0.0
u2_ref = omega * yr / zr  
u_ref = np.array([u1_ref, u2_ref], dtype=float)

# ==================== Density matrix real-vector conversion ================= #

# Precompute Hr/Hi for H0, H1, H2
H_list = [H0] + H_controls
H_real = [np.real(H).astype(float) for H in H_list]
H_imag = [np.imag(H).astype(float) for H in H_list]

def rho_to_real_vec(rho_qobj):
    rho = np.asarray(rho_qobj.full())
    A = np.real(rho)
    B = np.imag(rho)
    return np.concatenate([A.flatten(), B.flatten()]).astype(float)

def real_vec_to_rho(x_vec, dim=2):
    N = dim*dim
    A = x_vec[:N].reshape((dim, dim))
    B = x_vec[N:].reshape((dim, dim))
    return A + 1j*B

# Initial & target density matrices
rho0 = ket2dm(psi0)
rho_ref = ket2dm(psi_ref)

x0_np = rho_to_real_vec(rho0)
xref_np = rho_to_real_vec(rho_ref)

# ====================== CasADi symbolic model for density matrix ================= #
dim = 2
N = dim*dim

x = ca.MX.sym('x', 2*N)        # [A.flatten(); B.flatten()]
u = ca.MX.sym('u', nb_inputs)

# Build real/imag Hamiltonians
Hr = ca.DM(H_real[0]) + u[0]*ca.DM(H_real[1]) + u[1]*ca.DM(H_real[2])
Hi = ca.DM(H_imag[0]) + u[0]*ca.DM(H_imag[1]) + u[1]*ca.DM(H_imag[2])

# Split x into A and B
A = ca.reshape(x[:N], (dim, dim))
B = ca.reshape(x[N:], (dim, dim))

# Density matrix ODE: dA/dt, dB/dt
dA = Hr@B + Hi@A - B@Hr - A@Hi
dB = -Hr@A + Hi@B + A@Hr - B@Hi

xdot = ca.vertcat(ca.reshape(dA, N, 1), ca.reshape(dB, N, 1))
xdot_fun = ca.Function('xdot_fun', [x, u], [xdot])

# RK4 integrator (built once)
def _rk4(xk, uk, h):
    k1 = xdot_fun(xk, uk)
    k2 = xdot_fun(xk + 0.5*h*k1, uk)
    k3 = xdot_fun(xk + 0.5*h*k2, uk)
    k4 = xdot_fun(xk + h*k3, uk)
    return xk + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)

step_fun = ca.Function('step_fun', [x, u], [_rk4(x, u, dt)])

# Fidelity: Tr(ρ_target * ρ) = Tr((A_r + i B_r) @ (A + i B))
Ar = ca.reshape(xref_np[:N], (dim, dim))
Br = ca.reshape(xref_np[N:], (dim, dim))

def fidelity_from_x(xv):
    A = ca.reshape(xv[:dim*dim], dim, dim)
    B = ca.reshape(xv[dim*dim:], dim, dim)
    # Re Tr(rho_target^\dagger * rho) = Tr(Ar @ A + Br @ B)
    return ca.trace(Ar @ A + Br @ B)



# =========================== MPC settings =============================== #
lambda_u = 1e-4
lambda_x = 1.0
u_ref_dm = ca.DM(u_ref)

# IPOPT options (stable on Windows)
nlp_opts = {
    'ipopt.print_level': 0,
    'ipopt.max_iter': 150,
    'ipopt.tol': 1e-6,
    'ipopt.linear_solver': 'mumps',  # memory-friendly
    'print_time': 0
}

mpc_control = np.zeros((nb_inputs, T), dtype=float)
current_x = x0_np.copy()
U_prev_window = None

start_total = time.time()

for step_idx in range(nb_opts):
    t_idx = step_idx * m
    if t_idx >= T:
        break

    window_end = min(t_idx + L, T)
    N = window_end - t_idx
    apply_steps = min(m, N)

    # Decision vars: U (nb_inputs x N)
    U = ca.MX.sym('U', nb_inputs, N)

    # Single-shoot rollout1
    xk = ca.DM(current_x)
    J = 0
    u_prev = None
    for k in range(N):
        uk = U[:, k]
        # running penalties
        J += lambda_u * ca.sumsqr(uk - u_ref_dm)
        u_prev = uk
        xk = step_fun(xk, uk)
        J += lambda_x * (1.0 - fidelity_from_x(xk))

    # Build NLP
    nlp = {'x': ca.vec(U), 'f': J}
    solver = ca.nlpsol('solver', 'ipopt', nlp, nlp_opts)

    # Bounds u ∈ [-1,1]
    lbw = np.full(nb_inputs*N, -1.0)
    ubw = np.full(nb_inputs*N, 1.0)

    # Initial guess
    if U_prev_window is None:
        guess = np.zeros((nb_inputs, N), dtype=float)
        for i in range(nb_inputs):
            guess[i, :] = ampl0[i] * np.sin(np.linspace(0, np.pi, N))
    else:
        guess = np.zeros((nb_inputs, N), dtype=float)
        for i in range(nb_inputs):
            tail = U_prev_window[i, apply_steps:]
            n_fill = min(tail.shape[0], N)
            guess[i, :n_fill] = tail[:n_fill]

    # Use CasADi's vec to ensure correct column-wise ordering
    x0_guess = ca.vec(ca.DM(guess)).full()

    # Solve
    sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw)
    U_opt = np.array(sol['x']).reshape((nb_inputs, N), order='F')  # column-major

    # Apply first m steps
    for i in range(nb_inputs):
        mpc_control[i, t_idx:t_idx+apply_steps] = U_opt[i, :apply_steps]

    # Forward simulate current_x for apply_steps
    for local in range(apply_steps):
        uk = ca.DM(mpc_control[:, t_idx + local])
        current_x = np.array(step_fun(ca.DM(current_x), uk)).reshape(-1)

    # Warm start tail
    U_prev_window = U_opt.copy()

end_total = time.time()
print(f"=== Total MPC runtime (CasADi): {end_total - start_total:.2f} s ===")

# ============================= Final simulation ========================= #
# Use pure numpy/qutip (no CasADi) to avoid dtype mixing
state = psi0
proj0 = ket2dm(basis(2, 0))
proj1 = ket2dm(basis(2, 1))

populations = []
fidelities = []

for t in range(T):
    H = H0.copy()
    for i in range(nb_inputs):
        H = H + mpc_control[i, t] * H_controls[i]
    U_step = expm(-1j * H * dt)
    # evolve state as numpy -> Qobj
    vec = (U_step @ state.full()).reshape((2, 1))
    state = Qobj(vec, dims=[[2], [1]])

    fidelities.append(float(fidelity(state, psi_ref)))
    p0 = abs((basis(2,0).dag() * state)[0,0])**2
    p1 = abs((basis(2,1).dag() * state)[0,0])**2
    populations.append([p0, p1])

populations = np.array(populations)

# ================================ Plots ================================= #
plt.figure(figsize=(12, 8))

# Population Plot
plt.subplot(2, 2, 1)
plt.plot(full_tlist, populations[:, 0], label="Population in |0>")
plt.plot(full_tlist, populations[:, 1], label="Population in |1>")
plt.xlabel("t [ns]", fontsize=16)
plt.ylabel("Population", fontsize=16)
plt.title("State Populations", fontsize=18)
plt.grid(True, linestyle = '--')
#plt.title("A", fontsize=18, loc = 'left')
plt.legend()

# Fidelity Plot
plt.subplot(2, 2, 2)
plt.plot(full_tlist, fidelities, label="Fidelity")
plt.axhline(y=1.0, linestyle='--', label="Target")
plt.xlabel("t [ns]", fontsize=16)
plt.ylabel("Fidelity", fontsize=16)
plt.title("Fidelity Over Time", fontsize=18)1
plt.grid(True, linestyle = '--')
#plt.title("B", fontsize=18, loc = 'left')
plt.legend()

# Control Fields
plt.subplot(2, 1, 2)
for i in range(nb_inputs):
    plt.plot(full_tlist, mpc_control[i], label=f"Control Field {i+1}")
plt.xlabel("t [ns]", fontsize=16)
plt.ylabel("Amplitude", fontsize=16)
plt.title("Optimized Control Fields (MPC via CasADi)", fontsize=18)
plt.grid(True, linestyle = '--')
#plt.title("C", fontsize=18, loc = 'left')
plt.legend()

plt.tight_layout()
plt.show()

print(f"Final Fidelity: {fidelities[-1]:.9f}")
