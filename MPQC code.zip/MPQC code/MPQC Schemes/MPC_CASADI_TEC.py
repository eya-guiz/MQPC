# -*- coding: utf-8 -*-
"""
Created on Thu Sep  4 12:43:48 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 01:24:46 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
CasADi MPC for 3-Control Quantum System Benchmark
"""

import numpy as np
import casadi as ca
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import basis, sigmax, sigmay, sigmaz, ket2dm, fidelity, Qobj
import time

# Standard basis states
ket0 = basis(2, 0)       # |0>
ket1 = basis(2, 1)       # |1>

# Superposition states
ket_plus  = (ket0 + ket1).unit()        # |+>
ket_minus = (ket0 - ket1).unit()        # |->

ket_yplus  = (ket0 + 1j * ket1).unit()  # |y+>
ket_yminus = (ket0 - 1j * ket1).unit()  # |y->

class QuantumMPC_3Control:
    def __init__(self, t_end, T, L, m, ampl0, omega):
        """
        Initialize CasADi MPC controller for 3-control quantum system
        
        Parameters:
        t_end: total simulation time
        T: number of time steps
        L: prediction horizon steps
        m: control application steps
        ampl0: initial control amplitude guess [u1, u2, u3]
        omega: energy separation for drift Hamiltonian
        """
        # Time parameters
        self.t_end = t_end
        self.T = T
        self.dt = t_end / T
        self.full_tlist = np.linspace(0.0, t_end, T)
        
        # MPC parameters
        self.L = L  # Prediction horizon
        self.m = m   # Control application steps
        self.nb_opts = int(np.ceil(T / m))
        
        # System parameters
        self.nb_inputs = 3  # Now 3 controls: u1, u2, u3
        self.omega = omega
        self.ampl0 = ampl0
        
        # Pauli matrices (complex numpy)
        self.SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
        self.SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
        self.SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)
        
        # Hamiltonian components: H0 = ωσ_z, H1 = σ_x, H2 = σ_y, H3 = σ_z
        self.H0 = omega * self.SZ  # Drift Hamiltonian
        self.H_controls = [self.SX, self.SY, self.SZ]  # Control Hamiltonians
        
        # Initial state: ground state |0⟩
        self.psi0 = basis(2, 0)
        
        # Target state: choose any state on Bloch sphere
        self.psi_ref = ket1
        
        # Reference control (typically zero for regularization)
        self.u_ref = np.array([0.0, 0.0, 0.0], dtype=float)
        
        # Precompute real/imaginary parts of Hamiltonians
        H_list = [self.H0] + self.H_controls
        self.H_real = [np.real(H).astype(float) for H in H_list]
        self.H_imag = [np.imag(H).astype(float) for H in H_list]
        
        # Real-valued state representation
        self.x0_np = self.psi_to_real_vec(self.psi0)
        self.xref_np = self.psi_to_real_vec(self.psi_ref)
        
        # CasADi functions (built once)
        self.step_fun = self._build_casadi_functions()
        
        # Storage
        self.mpc_control = np.zeros((self.nb_inputs, self.T), dtype=float)
        self.fidelities = []
        self.populations = []
        self.runtimes = []
        self.current_x = self.x0_np.copy()
        self.U_prev_window = None
        
        # IPOPT options
        self.nlp_opts = {
            'ipopt.print_level': 0,
            'ipopt.max_iter': 150,
            'ipopt.tol': 1e-6,
            'ipopt.linear_solver': 'mumps',
            'print_time': 0
        }
        
        # Regularization parameters
        self.alpha = 1  # Control magnitude regularization
        self.lambda_u = 1e-4  # Control variation regularization
        
    def psi_to_real_vec(self, psi_qobj):
        """Convert Qobj state to real-valued vector [Re(ψ); Im(ψ)]"""
        psi = np.asarray(psi_qobj.full()).reshape(-1)
        a = np.real(psi)
        b = np.imag(psi)
        return np.concatenate([a, b]).astype(float)
    
    def _build_casadi_functions(self):
        """Build CasADi functions for dynamics and fidelity"""
        # Symbols
        x = ca.MX.sym('x', 4)            # [a0,a1,b0,b1]
        u = ca.MX.sym('u', self.nb_inputs)    # [u1, u2, u3]
        
        # Build Hr, Hi = H0 + u1*H1 + u2*H2 + u3*H3
        # Note: H3 = σ_z, same as H0 but with different coefficient
        Hr = (ca.DM(self.H_real[0]) +  # H0 (ωσ_z)
              u[0] * ca.DM(self.H_real[1]) +  # u1*σ_x
              u[1] * ca.DM(self.H_real[2]) +  # u2*σ_y
              u[2] * ca.DM(self.H_real[3]))   # u3*σ_z
        
        Hi = (ca.DM(self.H_imag[0]) +  # H0 (ωσ_z)
              u[0] * ca.DM(self.H_imag[1]) +  # u1*σ_x
              u[1] * ca.DM(self.H_imag[2]) +  # u2*σ_y
              u[2] * ca.DM(self.H_imag[3]))   # u3*σ_z
        
        a_vec = x[0:2]
        b_vec = x[2:4]
        
        # Real-valued ODE for Schrödinger dynamics
        f_a = Hr @ b_vec + Hi @ a_vec
        f_b = -Hr @ a_vec + Hi @ b_vec
        xdot = ca.vertcat(f_a, f_b)
        
        # Wrap dynamics
        xdot_fun = ca.Function('xdot_fun', [x, u], [xdot])
        
        # One RK4 step of size dt
        def _rk4(xk, uk, h):
            k1 = xdot_fun(xk, uk)
            k2 = xdot_fun(xk + 0.5*h*k1, uk)
            k3 = xdot_fun(xk + 0.5*h*k2, uk)
            k4 = xdot_fun(xk + h*k3, uk)
            return xk + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)
        
        step_fun = ca.Function('step_fun', [x, u], [_rk4(x, u, self.dt)])
        
        return step_fun
    
    def fidelity_from_x(self, xv):
        """Compute fidelity from real-valued state vector"""
        ar = ca.DM(self.xref_np[0:2])
        br = ca.DM(self.xref_np[2:4])
        
        a = xv[0:2]
        b = xv[2:4]
        cre = ca.dot(ar, a) + ca.dot(br, b)
        cim = ca.dot(ar, b) - ca.dot(br, a)
        return cre*cre + cim*cim
    
    def run_mpc(self):
        """Run the MPC controller with CasADi optimization and terminal constraint"""
        print("Starting CasADi MPC for 3-control quantum system with terminal constraint...")
        print(f"Parameters: T={self.T}, L={self.L}, m={self.m}")
        print(f"Target state: {self.psi_ref}")
        print(f"Initial state: {self.psi0}")
        
        start_total = time.time()
        
        for step_idx in range(self.nb_opts):
            t_idx = step_idx * self.m
            if t_idx >= self.T:
                break
                
            window_end = min(t_idx + self.L, self.T)
            N = window_end - t_idx
            apply_steps = min(self.m, N)
            
            step_start = time.time()
            
            # Decision variables: U (nb_inputs x N)
            U = ca.MX.sym('U', self.nb_inputs, N)
            
            # Single-shoot rollout
            xk = ca.DM(self.current_x)
            J = 0
            u_ref_dm = ca.DM(self.u_ref)
            
            # Store states for terminal constraint
            states = [xk]
            
            for k in range(N):
                uk = U[:, k]
                # Control regularization
                J += self.lambda_u * ca.sumsqr(uk - u_ref_dm)
                # State evolution
                xk = self.step_fun(xk, uk)
                states.append(xk)
                # Fidelity cost (main objective) - only intermediate states
                if k < N - 1:  # Don't include terminal state in cost
                    J += self.alpha * (1.0 - self.fidelity_from_x(xk))
            
            # Terminal equality constraint: fidelity(x_final, x_ref) = 1
            terminal_fidelity = self.fidelity_from_x(states[-1])
            terminal_constraint = terminal_fidelity - 1.0  # Should be 0
            
            # Build NLP with constraint
            nlp = {
                'x': ca.vec(U), 
                'f': J,
                'g': terminal_constraint  # Terminal equality constraint
            }
            
            solver = ca.nlpsol('solver', 'ipopt', nlp, self.nlp_opts)
            
            # Bounds u ∈ [-1,1] for all 3 controls
            lbw = np.full(self.nb_inputs * N, -1.0)
            ubw = np.full(self.nb_inputs * N, 1.0)
            
            # Constraint bounds (equality constraint: g = 0)
            lbg = [0.0]  # g >= 0
            ubg = [0.0]  # g <= 0 (so g = 0)
            
            # Initial guess
            if self.U_prev_window is None:
                guess = np.zeros((self.nb_inputs, N), dtype=float)
                for i in range(self.nb_inputs):
                    guess[i, :] = self.ampl0[i] * np.ones(N)
            else:
                guess = np.zeros((self.nb_inputs, N), dtype=float)
                for i in range(self.nb_inputs):
                    tail = self.U_prev_window[i, apply_steps:]
                    n_fill = min(tail.shape[0], N)
                    guess[i, :n_fill] = tail[:n_fill]
                    if n_fill < N:
                        guess[i, n_fill:] = self.ampl0[i]  # Fill remainder
            
            # Solve
            x0_guess = ca.vec(ca.DM(guess)).full()
            sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
            
            # Check constraint satisfaction
            constraint_value = float(sol['g'])
            print(f"Terminal constraint value: {constraint_value:.6e}")
            
            U_opt = np.array(sol['x']).reshape((self.nb_inputs, N), order='F')
            
            # Store runtime
            step_time = time.time() - step_start
            self.runtimes.append(step_time)
            
            print(f"Step {step_idx+1}: Time={step_time:.3f}s, Horizon={N}, Constraint={constraint_value:.2e}")
            
            # Apply first m steps
            for i in range(self.nb_inputs):
                self.mpc_control[i, t_idx:t_idx+apply_steps] = U_opt[i, :apply_steps]
            
            # Forward simulate for applied steps
            for local in range(apply_steps):
                uk = ca.DM(self.mpc_control[:, t_idx + local])
                self.current_x = np.array(self.step_fun(ca.DM(self.current_x), uk)).reshape(-1)
            
            # Warm start for next iteration
            self.U_prev_window = U_opt.copy()
        
        total_time = time.time() - start_total
        print(f"CasADi MPC completed in {total_time:.2f} seconds")
        print(f"Average step time: {np.mean(self.runtimes):.3f} seconds")
        
        return total_time
    
    def simulate_final_trajectory(self):
        """Simulate the final trajectory using the optimized controls"""
        print("Simulating final trajectory...")
        
        state = self.psi0
        self.fidelities = []
        self.populations = []
        
        proj0 = ket2dm(basis(2, 0))
        proj1 = ket2dm(basis(2, 1))
        
        for t in range(self.T):
            # Build Hamiltonian: H0 + u1*H1 + u2*H2 + u3*H3
            H = self.H0.copy()
            for i in range(self.nb_inputs):
                H = H + self.mpc_control[i, t] * self.H_controls[i]
            
            # Time evolution
            U_step = expm(-1j * H * self.dt)
            vec = (U_step @ state.full()).reshape((2, 1))
            state = Qobj(vec, dims=[[2], [1]])
            
            # Store results
            self.fidelities.append(float(fidelity(state, self.psi_ref)))
            p0 = abs((basis(2, 0).dag() * state)[0, 0])**2
            p1 = abs((basis(2, 1).dag() * state)[0, 0])**2
            self.populations.append([p0, p1])
        
        self.populations = np.array(self.populations)
        
        final_fidelity = self.fidelities[-1]
        print(f"Final fidelity: {final_fidelity:.9f}")
        
        return final_fidelity
    
    def plot_results(self):
        """Plot the results"""
        populations = np.array(self.populations)
        
        plt.figure(figsize=(18, 12))
        
        # Population Plot
        plt.subplot(3, 2, 1)
        plt.plot(self.full_tlist, populations[:, 0], label="Population in |0>", linewidth=2)
        plt.plot(self.full_tlist, populations[:, 1], label="Population in |1>", linewidth=2)
        plt.xlabel("Time")
        plt.ylabel("Population")
        plt.title("State Populations")
        plt.legend()
        plt.grid(True)
        
        # Fidelity Plot
        plt.subplot(3, 2, 2)
        plt.plot(self.full_tlist, self.fidelities, label="Fidelity", linewidth=2, color='purple')
        plt.axhline(y=1.0, color='r', linestyle='--', label="Target")
        plt.xlabel("Time")
        plt.ylabel("Fidelity")
        plt.title("Fidelity Over Time")
        plt.legend()
        plt.grid(True)
        
        # Control Fields with bounds
        control_labels = ['u₁ (σ_x)', 'u₂ (σ_y)', 'u₃ (σ_z)']
        colors = ['red', 'green', 'blue']
        
        for i in range(self.nb_inputs):
            plt.subplot(3, 2, 3 + i)
            plt.plot(self.full_tlist, self.mpc_control[i], label=control_labels[i], 
                    color=colors[i], linewidth=2)
            plt.axhline(y=1.0, color='gray', linestyle='--', alpha=0.7, label='Upper bound')
            plt.axhline(y=-1.0, color='gray', linestyle='--', alpha=0.7, label='Lower bound')
            plt.fill_between(self.full_tlist, -1.0, 1.0, color='gray', alpha=0.1)
            plt.xlabel("Time")
            plt.ylabel("Amplitude")
            plt.title(f"Control Field {control_labels[i]}")
            plt.legend()
            plt.grid(True)
            plt.ylim(-1.2, 1.2)
        
        plt.tight_layout()
        plt.show()
        
        # Verify bounds
        self.verify_bounds()
    
    def verify_bounds(self):
        """Verify that control bounds are satisfied"""
        print(f"\n=== BOUND CONSTRAINT VERIFICATION ===")
        control_labels = ['u₁ (σ_x)', 'u₂ (σ_y)', 'u₃ (σ_z)']
        
        for i in range(self.nb_inputs):
            controls = self.mpc_control[i, :]
            violations = np.sum((controls < -1.0) | (controls > 1.0))
            min_val, max_val = np.min(controls), np.max(controls)
            print(f"{control_labels[i]}: violations={violations}, range=[{min_val:.3f}, {max_val:.3f}]")
        
        total_violations = sum(np.sum((self.mpc_control[i, :] < -1.0) | 
                                     (self.mpc_control[i, :] > 1.0)) 
                             for i in range(self.nb_inputs))
        
        if total_violations == 0:
            print("✓ All controls satisfy bound constraints [-1, 1]")
        else:
            print(f"✗ Total violations: {total_violations}")
    
    def analyze_performance(self):
        """Analyze controller performance"""
        print("\n" + "="*60)
        print("PERFORMANCE ANALYSIS")
        print("="*60)
        
        final_fidelity = self.fidelities[-1] if self.fidelities else 0.0
        print(f"Final Fidelity: {final_fidelity:.6f}")
        print(f"Infidelity: {1 - final_fidelity:.3e}")
        
        # Control statistics
        control_labels = ['u₁ (σ_x)', 'u₂ (σ_y)', 'u₃ (σ_z)']
        total_energy = 0
        
        for i in range(self.nb_inputs):
            energy = np.sum(self.mpc_control[i, :]**2) * self.dt
            total_energy += energy
            print(f"{control_labels[i]} Energy: {energy:.4f}")
        
        print(f"Total Control Energy: {total_energy:.4f}")
        
        # Runtime statistics
        if self.runtimes:
            total_opt_time = sum(self.runtimes)
            avg_time = np.mean(self.runtimes)
            print(f"Total Optimization Time: {total_opt_time:.2f} s")
            print(f"Average per Step: {avg_time:.3f} s")
            print(f"Number of MPC Steps: {len(self.runtimes)}")
        
        # Effective Hamiltonian analysis
        print(f"\nEffective Hamiltonian Analysis:")
        print(f"Drift strength ω: {self.omega}")
        print(f"Average u₃ control: {np.mean(self.mpc_control[2, :]):.3f}")
        print(f"Effective z-component: {self.omega + np.mean(self.mpc_control[2, :]):.3f}")

# Run the simulation
if __name__ == "__main__":
    # Initialize CasADi MPC controller for 3-control system
    mpc_3control = QuantumMPC_3Control(
        t_end=2.0,
        T=40,
        L=40,
        m=40,
        ampl0=[0.2, 0.2, 0.2],  # Initial guesses for u1, u2, u3
        omega= -0.5 # Drift strength
    )
    
    # Run MPC
    total_time = mpc_3control.run_mpc()
    
    # Simulate final trajectory
    final_fidelity = mpc_3control.simulate_final_trajectory()
    
    # Plot results
    mpc_3control.plot_results()
    
    # Performance analysis
    mpc_3control.analyze_performance()
    
    # Access results for further analysis
    print(f"\nControl arrays shapes:")
    for i in range(mpc_3control.nb_inputs):
        print(f"Control {i+1}: {mpc_3control.mpc_control[i, :].shape}")
    
    print(f"Fidelity array length: {len(mpc_3control.fidelities)}")