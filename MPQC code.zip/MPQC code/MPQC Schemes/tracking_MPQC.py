# -*- coding: utf-8 -*-
"""
Created on Thu Sep  4 11:17:41 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 18:23:36 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Tracking MPC for a 2-level quantum system using CasADi
@author: eya20
"""

import numpy as np
import casadi as ca
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import basis, ket2dm, fidelity, Qobj
import time

# -------------------------- Quantum System Class -------------------------- #
class TwoLevelQuantumSystem:
    def __init__(self, omega=-0.5, nb_inputs=3):
        self.dim = 2
        self.nb_inputs = nb_inputs
        # Pauli matrices
        self.SX = np.array([[0,1],[1,0]], dtype=np.complex128)
        self.SY = np.array([[0,-1j],[1j,0]], dtype=np.complex128)
        self.SZ = np.array([[1,0],[0,-1]], dtype=np.complex128)
        # Drift and control Hamiltonians
        self.H0 = omega * self.SZ
        self.H_controls = [self.SX, self.SY, self.SZ]
    
    @staticmethod
    def rho_to_real_vec(rho_qobj):
        rho = np.asarray(rho_qobj.full())
        return np.concatenate([rho.real.flatten(), rho.imag.flatten()])

    @staticmethod
    def real_vec_to_rho(x_vec, dim=2):
        N = dim*dim
        A = x_vec[:N].reshape((dim, dim))
        B = x_vec[N:].reshape((dim, dim))
        return A + 1j*B

# -------------------------- Tracking MPC Class ---------------------------- #
class TrackingMPC:
    def __init__(self, system, x0_qobj, xref_qobj, T, t_end, L, m):
        self.sys = system
        self.T = T
        self.dt = t_end / T
        self.full_tlist = np.linspace(0, t_end, T)
        self.L = L
        self.m = m
        self.nb_opts = int(np.ceil(T/m))
        self.dim = system.dim
        self.dim_rho = self.dim**2

        # Initial & target density matrices
        self.x0 = TwoLevelQuantumSystem.rho_to_real_vec(x0_qobj)
        self.xref = TwoLevelQuantumSystem.rho_to_real_vec(xref_qobj)

        # CasADi setup
        self._setup_casadi_functions()
        
        # MPC history
        self.mpc_control = np.zeros((self.sys.nb_inputs, self.T))
        self.xs_history = []
        self.us_history = []
        self.runtimes = []

    def _setup_casadi_functions(self):
        # Real/imag Hamiltonians
        H_list = [self.sys.H0] + self.sys.H_controls
        self.H_real = [np.real(H).astype(float) for H in H_list]
        self.H_imag = [np.imag(H).astype(float) for H in H_list]

        # CasADi symbols
        x = ca.MX.sym('x', 2*self.dim_rho)
        u = ca.MX.sym('u', self.sys.nb_inputs)
        Hr = ca.DM(self.H_real[0])
        Hi = ca.DM(self.H_imag[0])
        for i in range(self.sys.nb_inputs):
            Hr += u[i]*ca.DM(self.H_real[i+1])
            Hi += u[i]*ca.DM(self.H_imag[i+1])
        A = ca.reshape(x[:self.dim_rho], (self.dim, self.dim))
        B = ca.reshape(x[self.dim_rho:], (self.dim, self.dim))
        dA = Hr@B + Hi@A - B@Hr - A@Hi
        dB = -Hr@A + Hi@B + A@Hr - B@Hi
        xdot = ca.vertcat(ca.reshape(dA, self.dim_rho, 1), ca.reshape(dB, self.dim_rho, 1))
        self.xdot_fun = ca.Function('xdot_fun', [x,u], [xdot])

        # RK4 integrator
        def rk4(xk, uk, h=self.dt):
            k1 = self.xdot_fun(xk, uk)
            k2 = self.xdot_fun(xk + 0.5*h*k1, uk)
            k3 = self.xdot_fun(xk + 0.5*h*k2, uk)
            k4 = self.xdot_fun(xk + h*k3, uk)
            return xk + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)
        self.step_fun = ca.Function('step_fun', [x,u], [rk4(x,u)])

        # Fidelity functions
        Ar = ca.reshape(self.xref[:self.dim_rho], (self.dim, self.dim))
        Br = ca.reshape(self.xref[self.dim_rho:], (self.dim, self.dim))
        self.fidelity_from_x = lambda xv: ca.trace(Ar @ ca.reshape(xv[:self.dim_rho], (self.dim,self.dim)) + 
                                                   Br @ ca.reshape(xv[self.dim_rho:], (self.dim,self.dim)))
        self.fidelity_between = lambda xa, xb: ca.trace(
            ca.reshape(xa[:self.dim_rho],(self.dim,self.dim)) @ ca.reshape(xb[:self.dim_rho],(self.dim,self.dim)) +
            ca.reshape(xa[self.dim_rho:],(self.dim,self.dim)) @ ca.reshape(xb[self.dim_rho:],(self.dim,self.dim))
        )

    def real_vec_to_rho(self, x_vec):
        """Convert real vector back to density matrix"""
        return TwoLevelQuantumSystem.real_vec_to_rho(x_vec, self.dim)

    def run_mpc(self):
        lambda_u, lambda_x = 1e-4, 1.0
        lambda_xs, lambda_us = 5.0, 1.0 #100.0, 1000.0
        u_ref_dm = ca.DM(np.array([0,1, 0.5]))
        current_x = self.x0.copy()
        U_prev_window = None
        start_total = time.time()

        for step_idx in range(self.nb_opts):
            t_idx = step_idx * self.m
            if t_idx >= self.T:
                break
                
            step_start = time.time()
            window_end = min(t_idx + self.L, self.T)
            N = window_end - t_idx
            apply_steps = min(self.m, N)

            # Decision variables
            U = ca.MX.sym('U', self.sys.nb_inputs, N)
            xs = ca.MX.sym('xs', 2*self.dim_rho, 1)
            us = ca.MX.sym('us', self.sys.nb_inputs, 1)
            X = ca.vertcat(ca.vec(U), xs, us)

            # Single-shoot rollout
            xk = ca.DM(current_x)
            J = 0
            for k in range(N):
                uk = U[:,k]
                J += lambda_u*ca.sumsqr(uk - us)
                xk = self.step_fun(xk, uk)
                J += lambda_x*(1.0 - self.fidelity_between(xk, xs))

            J += lambda_xs*(1.0 - self.fidelity_from_x(xs))
            J += lambda_us*ca.sumsqr(us - u_ref_dm)
            J += 1e-8*(ca.sumsqr(xs) + ca.sumsqr(us))

            # Constraints
            g = xk - xs
            g = ca.vertcat(g, self.xdot_fun(xs, us))
            lbg = ca.DM.zeros(g.shape[0])
            ubg = ca.DM.zeros(g.shape[0])

            # Build NLP
            nlp = {'x': X, 'f': J, 'g': g}
            solver = ca.nlpsol('solver', 'ipopt', nlp, {
                'ipopt.print_level': 0,
                'ipopt.max_iter': 150,
                'ipopt.tol': 1e-6,
                'print_time': 0
            })

            # Bounds
            nv = self.sys.nb_inputs*N + 2*self.dim_rho + self.sys.nb_inputs
            lbw = -ca.inf*ca.DM.ones(nv,1)
            ubw = ca.inf*ca.DM.ones(nv,1)
            lbw[:self.sys.nb_inputs*N] = -1.0
            ubw[:self.sys.nb_inputs*N] = 1.0
            offset_us = self.sys.nb_inputs*N + 2*self.dim_rho
            lbw[offset_us:offset_us+self.sys.nb_inputs] = -1.0
            ubw[offset_us:offset_us+self.sys.nb_inputs] = 1.0

            # Initial guess = repeat u_ref across horizon
            if U_prev_window is None:
                guess = np.tile(np.array(u_ref_dm).reshape(-1,1), (1, N))
            else:
                guess = np.zeros((self.sys.nb_inputs, N))
                for i in range(self.sys.nb_inputs):
                    tail = U_prev_window[i, apply_steps:]
                    n_fill = min(tail.shape[0], N)
                    guess[i, :n_fill] = tail[:n_fill]
                    if n_fill < N:
                        guess[i, n_fill:] = float(u_ref_dm[i])  # fill with steady-state ref

            #x0_guess = ca.vertcat(ca.vec(ca.DM(guess)), current_x , ca.vec(ca.DM(np.array([0,-1,0.5]))))
            #x0_guess = ca.vertcat(ca.vec(ca.DM(guess)), current_x, ca.vec(ca.DM(guess[:,-1])))
            x0_guess = ca.vertcat(ca.vec(ca.DM(guess)), self.xref, ca.vec(self.mpc_control[:,-1]))

            # Solve NLP
            sol = solver(x0=x0_guess, lbg=lbg, ubg=ubg, lbx=lbw, ubx=ubw)
            X_opt = np.array(sol['x']).flatten()
            U_opt_vec = X_opt[:self.sys.nb_inputs*N]
            U_opt = U_opt_vec.reshape((self.sys.nb_inputs,N), order='F')
            xs_opt = X_opt[self.sys.nb_inputs*N:self.sys.nb_inputs*N + 2*self.dim_rho]
            us_opt = X_opt[self.sys.nb_inputs*N + 2*self.dim_rho:]
            self.xs_history.append(xs_opt)
            self.us_history.append(us_opt)

            # Apply first m steps
            for i in range(self.sys.nb_inputs):
                self.mpc_control[i, t_idx:t_idx+apply_steps] = U_opt[i,:apply_steps]

            # Forward simulate current_x
            for local in range(apply_steps):
                uk = ca.DM(self.mpc_control[:, t_idx + local])
                current_x = np.array(self.step_fun(ca.DM(current_x), uk)).flatten()

            U_prev_window = U_opt.copy()
            step_time = time.time() - step_start
            self.runtimes.append(step_time)
            
            if step_idx % 10 == 0:
                print(f"Step {step_idx+1}: Time={step_time:.3f}s, Horizon={N}")

        total_time = time.time() - start_total
        print(f"=== Total MPC runtime: {total_time:.2f} s ===")
        print(f"Average step time: {np.mean(self.runtimes):.3f} s")
        
    def simulate_final_trajectory(self, psi0, psi_ref):
        """Simulate the final trajectory"""
        state = psi0
        fidelities = []
        populations = []

        for t in range(self.T):
            H = self.sys.H0.copy()
            for i in range(self.sys.nb_inputs):
                H += self.mpc_control[i, t] * self.sys.H_controls[i]
            U_step = expm(-1j * H * self.dt)
            state = Qobj(U_step @ state.full(), dims=[[2],[1]])
            fidelities.append(float(fidelity(state, psi_ref)))
            p0 = abs((basis(2, 0).dag() * state)[0, 0])**2
            p1 = abs((basis(2, 1).dag() * state)[0, 0])**2
            populations.append([p0, p1])

        return np.array(fidelities), np.array(populations)

    def plot_results(self, psi0, psi_ref):
        """Plot trajectory fidelity and intermediate MPC steady-state fidelities."""
        # Simulate final trajectory
        fidelities, populations = self.simulate_final_trajectory(psi0, psi_ref)
    
        # Extract fidelities for intermediate steady states (xs_history)
        xs_fidelities = []
        for xs in self.xs_history:
            rho_xs = self.real_vec_to_rho(xs)
            xs_fidelities.append(float(fidelity(Qobj(rho_xs), psi_ref)))
        xs_fidelities = np.array(xs_fidelities)
    
        # Plot
        fig, ax = plt.subplots(figsize=(10, 6))
    
        # Fidelity of full trajectory
        ax.plot(self.full_tlist, fidelities, 'b-', linewidth=3, color = 'tab:blue',
                label=r' Fidelity of $\psi_t$')
        ax.axhline(y=1.0, color='r', linestyle='--', linewidth = 3,
                   label='Target fidelity')
    
        # Intermediate xs fidelities (plotted at MPC step times)
        step_times = np.linspace(0, self.full_tlist[-1], len(xs_fidelities))
        ax.plot(step_times, xs_fidelities, 'ko--', linewidth=3, color = 'tab:green',
                label=r'Fidelity of $\psi_s(t)$')
    
        # Labels & formatting
        ax.set_xlabel('Time $t$', fontsize=20)
        ax.set_ylabel('Fidelity', fontsize=20)
        ax.set_ylim(0, 1.05)
        ax.tick_params(axis='both', labelsize=16)
        ax.grid(True, linestyle='--', alpha=0.7)
        ax.legend(fontsize=16, loc='best', frameon=True)
    
        # Tighter layout
        plt.tight_layout()
        plt.show()
    
        # Print detailed information about xs_history
        print("\n=== INTERMEDIATE STEADY-STATES ANALYSIS ===")
        print(f"Number of intermediate steady states: {len(self.xs_history)}")
        print(f"Final intermediate fidelity: {xs_fidelities[-1]:.6f}")
        print(f"Range of intermediate fidelities: [{min(xs_fidelities):.6f}, {max(xs_fidelities):.6f}]")
        print(f"Final trajectory fidelity: {fidelities[-1]:.9f}")

# --------------------------- Run Example --------------------------------- #

# Standard basis states
ket0 = basis(2, 0)       # |0>
ket1 = basis(2, 1)       # |1>

# Superposition states
ket_plus  = (ket0 + ket1).unit()        # |+>
ket_minus = (ket0 - ket1).unit()        # |->

ket_yplus  = (ket0 + 1j * ket1).unit()  # |y+>
ket_yminus = (ket0 - 1j * ket1).unit()  # |y->


if __name__ == "__main__":
    psi0 = ket0
    psi_ref = ket1
    
    # Initialize system and MPC
    system = TwoLevelQuantumSystem()
    mpc = TrackingMPC(system, ket2dm(psi0), ket2dm(psi_ref), T=40, t_end=2.0, L=5, m=1)
    
    # Run MPC
    mpc.run_mpc()
    
    # Plot results
    mpc.plot_results(psi0, psi_ref)
