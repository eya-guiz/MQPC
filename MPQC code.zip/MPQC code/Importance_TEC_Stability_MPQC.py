# -*- coding: utf-8 -*-
"""
Created on Wed Sep  3 12:55:34 2025

@author: eya20
"""

# -*- coding: utf-8 -*-
"""
Comparison of MPC with and without Terminal Constraint for Single Control Quantum System
"""

import numpy as np
import casadi as ca
from scipy.linalg import expm
import matplotlib.pyplot as plt
from qutip import basis, sigmax, sigmay, sigmaz, ket2dm, fidelity, Qobj
import time

# Standard basis states
ket0 = basis(2, 0)       # |0>
ket1 = basis(2, 1)       # |1>

# Superposition states
ket_plus  = (ket0 + ket1).unit()        # |+>
ket_minus = (ket0 - ket1).unit()        # |->

ket_yplus  = (ket0 + 1j * ket1).unit()  # |y+>
ket_yminus = (ket0 - 1j * ket1).unit()  # |y->

class QuantumMPC_Base:
    def __init__(self, t_end, T, L, m, ampl0, omega):
        """
        Base class for MPC controllers
        
        Parameters:
        t_end: total simulation time
        T: number of time steps
        L: prediction horizon steps
        m: control application steps
        ampl0: initial control amplitude guess
        omega: energy separation for drift Hamiltonian
        """
        # Time parameters
        self.t_end = t_end
        self.T = T
        self.dt = t_end / T
        self.full_tlist = np.linspace(0.0, t_end, T)
        
        # MPC parameters
        self.L = L  # Prediction horizon
        self.m = m   # Control application steps
        self.nb_opts = int(np.ceil(T / m))
        
        # System parameters
        self.nb_inputs = 1  # Single control
        self.omega = omega
        self.ampl0 = ampl0
        
        # Pauli matrices (complex numpy)
        self.SX = np.array([[0.0, 1.0], [1.0, 0.0]], dtype=np.complex128)
        self.SY = np.array([[0.0, -1.0j], [1.0j, 0.0]], dtype=np.complex128)
        self.SZ = np.array([[1.0, 0.0], [0.0, -1.0]], dtype=np.complex128)
        
        # Hamiltonian components: H0 = ωσ_z, H1 = σ_x
        self.H0 = omega * self.SZ  # Drift Hamiltonian
        self.H_controls = [self.SX]  # Control Hamiltonians (only σ_x)
        
        # Initial state: |+⟩
        self.psi0 = ket_plus
        
        # Target state: |-⟩
        self.psi_ref = ket_minus
        
        # Reference control (typically zero for regularization)
        self.u_ref = np.array([0.0], dtype=float)
        
        # Precompute real/imaginary parts of Hamiltonians
        H_list = [self.H0] + self.H_controls
        self.H_real = [np.real(H).astype(float) for H in H_list]
        self.H_imag = [np.imag(H).astype(float) for H in H_list]
        
        # Real-valued state representation
        self.x0_np = self.psi_to_real_vec(self.psi0)
        self.xref_np = self.psi_to_real_vec(self.psi_ref)
        
        # CasADi functions (built once)
        self.step_fun = self._build_casadi_functions()
        
        # Storage
        self.mpc_control = np.zeros((self.nb_inputs, self.T), dtype=float)
        self.fidelities = []
        self.populations = []
        self.runtimes = []
        self.current_x = self.x0_np.copy()
        self.U_prev_window = None
        
        # IPOPT options
        self.nlp_opts = {
            'ipopt.print_level': 0,
            'ipopt.max_iter': 200,
            'ipopt.tol': 1e-6,
            'ipopt.linear_solver': 'mumps',
            'print_time': 0
        }
        
        # Regularization parameters
        self.alpha = 1  # Control magnitude regularization
        self.lambda_u = 1e-4  # Control variation regularization
        
    def psi_to_real_vec(self, psi_qobj):
        """Convert Qobj state to real-valued vector [Re(ψ); Im(ψ)]"""
        psi = np.asarray(psi_qobj.full()).reshape(-1)
        a = np.real(psi)
        b = np.imag(psi)
        return np.concatenate([a, b]).astype(float)
    
    def _build_casadi_functions(self):
        """Build CasADi functions for dynamics and fidelity"""
        # Symbols
        x = ca.MX.sym('x', 4)            # [a0,a1,b0,b1]
        u = ca.MX.sym('u', self.nb_inputs)    # [u1]
        
        # Build Hr, Hi = H0 + u1*H1
        Hr = (ca.DM(self.H_real[0]) +  # H0 (ωσ_z)
              u[0] * ca.DM(self.H_real[1])  # u1*σ_x
              )
        
        Hi = (ca.DM(self.H_imag[0]) +  # H0 (ωσ_z)
              u[0] * ca.DM(self.H_imag[1])   # u1*σ_x
              )
        
        a_vec = x[0:2]
        b_vec = x[2:4]
        
        # Real-valued ODE for Schrödinger dynamics
        f_a = Hr @ b_vec + Hi @ a_vec
        f_b = -Hr @ a_vec + Hi @ b_vec
        xdot = ca.vertcat(f_a, f_b)
        
        # Wrap dynamics
        xdot_fun = ca.Function('xdot_fun', [x, u], [xdot])
        
        # One RK4 step of size dt
        def _rk4(xk, uk, h):
            k1 = xdot_fun(xk, uk)
            k2 = xdot_fun(xk + 0.5*h*k1, uk)
            k3 = xdot_fun(xk + 0.5*h*k2, uk)
            k4 = xdot_fun(xk + h*k3, uk)
            return xk + (h/6.0)*(k1 + 2*k2 + 2*k3 + k4)
        
        step_fun = ca.Function('step_fun', [x, u], [_rk4(x, u, self.dt)])
        
        return step_fun
    
    def fidelity_from_x(self, xv):
        """Compute fidelity from real-valued state vector"""
        ar = ca.DM(self.xref_np[0:2])
        br = ca.DM(self.xref_np[2:4])
        
        a = xv[0:2]
        b = xv[2:4]
        cre = ca.dot(ar, a) + ca.dot(br, b)
        cim = ca.dot(ar, b) - ca.dot(br, a)
        return cre*cre + cim*cim
    
    def simulate_final_trajectory(self):
        """Simulate the final trajectory using the optimized controls"""
        print("Simulating final trajectory...")
        
        state = self.psi0
        self.fidelities = []
        self.populations = []
        
        for t in range(self.T):
            # Build Hamiltonian: H0 + u1*H1
            H = self.H0.copy()
            for i in range(self.nb_inputs):
                H = H + self.mpc_control[i, t] * self.H_controls[i]
            
            # Time evolution
            U_step = expm(-1j * H * self.dt)
            vec = (U_step @ state.full()).reshape((2, 1))
            state = Qobj(vec, dims=[[2], [1]])
            
            # Store results
            self.fidelities.append(float(fidelity(state, self.psi_ref)))
            p0 = abs((basis(2, 0).dag() * state)[0, 0])**2
            p1 = abs((basis(2, 1).dag() * state)[0, 0])**2
            self.populations.append([p0, p1])
        
        self.populations = np.array(self.populations)
        
        final_fidelity = self.fidelities[-1]
        print(f"Final fidelity: {final_fidelity:.9f}")
        
        return final_fidelity

class QuantumMPC_NoTerminal(QuantumMPC_Base):
    """MPC without terminal constraint"""
    
    def run_mpc(self):
        """Run the MPC controller with CasADi optimization"""
        print("Starting CasADi MPC without terminal constraint...")
        print(f"Parameters: T={self.T}, L={self.L}, m={self.m}")
        print(f"Target state: {self.psi_ref}")
        print(f"Initial state: {self.psi0}")
        
        start_total = time.time()
        
        for step_idx in range(self.nb_opts):
            t_idx = step_idx * self.m
            if t_idx >= self.T:
                break
                
            window_end = min(t_idx + self.L, self.T)
            N = window_end - t_idx
            apply_steps = min(self.m, N)
            
            step_start = time.time()
            
            # Decision variables: U (nb_inputs x N)
            U = ca.MX.sym('U', self.nb_inputs, N)
            
            # Single-shoot rollout
            xk = ca.DM(self.current_x)
            J = 0
            u_ref_dm = ca.DM(self.u_ref)
            
            for k in range(N):
                uk = U[:, k]
                # Control regularization
                J += self.lambda_u * ca.sumsqr(uk - u_ref_dm)
                # State evolution
                xk = self.step_fun(xk, uk)
                # Fidelity cost (main objective)
                J += self.alpha * (1.0 - self.fidelity_from_x(xk))
            
            # Build NLP
            nlp = {'x': ca.vec(U), 'f': J}
            solver = ca.nlpsol('solver', 'ipopt', nlp, self.nlp_opts)
            
            # Bounds u ∈ [-1,1]
            lbw = np.full(self.nb_inputs * N, -1.0)
            ubw = np.full(self.nb_inputs * N, 1.0)
            
            # Initial guess
            if self.U_prev_window is None:
                guess = np.zeros((self.nb_inputs, N), dtype=float)
                for i in range(self.nb_inputs):
                    guess[i, :] = self.ampl0 * np.ones(N)
            else:
                guess = np.zeros((self.nb_inputs, N), dtype=float)
                for i in range(self.nb_inputs):
                    tail = self.U_prev_window[i, apply_steps:]
                    n_fill = min(tail.shape[0], N)
                    guess[i, :n_fill] = tail[:n_fill]
                    if n_fill < N:
                        guess[i, n_fill:] = self.ampl0  # Fill remainder
            
            # Solve
            x0_guess = ca.vec(ca.DM(guess)).full()
            sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw)
            U_opt = np.array(sol['x']).reshape((self.nb_inputs, N), order='F')
            
            # Store runtime
            step_time = time.time() - step_start
            self.runtimes.append(step_time)
            
            print(f"Step {step_idx+1}: Time={step_time:.3f}s, Horizon={N}")
            
            # Apply first m steps
            for i in range(self.nb_inputs):
                self.mpc_control[i, t_idx:t_idx+apply_steps] = U_opt[i, :apply_steps]
            
            # Forward simulate for applied steps
            for local in range(apply_steps):
                uk = ca.DM(self.mpc_control[:, t_idx + local])
                self.current_x = np.array(self.step_fun(ca.DM(self.current_x), uk)).reshape(-1)
            
            # Warm start for next iteration
            self.U_prev_window = U_opt.copy()
        
        total_time = time.time() - start_total
        print(f"CasADi MPC completed in {total_time:.2f} seconds")
        print(f"Average step time: {np.mean(self.runtimes):.3f} seconds")
        
        return total_time

class QuantumMPC_Terminal(QuantumMPC_Base):
    """MPC with terminal constraint"""
    
    def run_mpc(self):
        """Run the MPC controller with CasADi optimization and terminal constraint"""
        print("Starting CasADi MPC with terminal constraint...")
        print(f"Parameters: T={self.T}, L={self.L}, m={self.m}")
        print(f"Target state: {self.psi_ref}")
        print(f"Initial state: {self.psi0}")
        
        start_total = time.time()
        
        for step_idx in range(self.nb_opts):
            t_idx = step_idx * self.m
            if t_idx >= self.T:
                break
                
            window_end = min(t_idx + self.L, self.T)
            N = window_end - t_idx
            apply_steps = min(self.m, N)
            
            step_start = time.time()
            
            # Decision variables: U (nb_inputs x N)
            U = ca.MX.sym('U', self.nb_inputs, N)
            
            # Single-shoot rollout
            xk = ca.DM(self.current_x)
            J = 0
            u_ref_dm = ca.DM(self.u_ref)
            
            # Store all states for terminal constraint
            states = [xk]
            
            for k in range(N):
                uk = U[:, k]
                # Control regularization
                J += self.lambda_u * ca.sumsqr(uk - u_ref_dm)
                # State evolution
                xk = self.step_fun(xk, uk)
                states.append(xk)
                # Fidelity cost (main objective) - only intermediate states
                if k < N - 1:  # Don't include terminal state in cost
                    J += self.alpha * (1.0 - self.fidelity_from_x(xk))
            
            # Terminal state constraint: fidelity(x_final, x_ref) = 1
            terminal_fidelity = self.fidelity_from_x(states[-1])
            terminal_constraint = terminal_fidelity - 1.0  # Should be 0
            
            # Build NLP with constraint
            nlp = {
                'x': ca.vec(U), 
                'f': J,
                'g': terminal_constraint  # Terminal equality constraint
            }
            
            solver = ca.nlpsol('solver', 'ipopt', nlp, self.nlp_opts)
            
            # Bounds u ∈ [-1,1]
            lbw = np.full(self.nb_inputs * N, -1.0)
            ubw = np.full(self.nb_inputs * N, 1.0)
            
            # Constraint bounds (equality constraint: g = 0)
            lbg = [0.0]  # g >= 0
            ubg = [0.0]  # g <= 0 (so g = 0)
            
            # Initial guess
            if self.U_prev_window is None:
                guess = np.zeros((self.nb_inputs, N), dtype=float)
                for i in range(self.nb_inputs):
                    guess[i, :] = self.ampl0 * np.ones(N)
            else:
                guess = np.zeros((self.nb_inputs, N), dtype=float)
                for i in range(self.nb_inputs):
                    tail = self.U_prev_window[i, apply_steps:]
                    n_fill = min(tail.shape[0], N)
                    guess[i, :n_fill] = tail[:n_fill]
                    if n_fill < N:
                        guess[i, n_fill:] = self.ampl0  # Fill remainder
            
            # Solve
            x0_guess = ca.vec(ca.DM(guess)).full()
            sol = solver(x0=x0_guess, lbx=lbw, ubx=ubw, lbg=lbg, ubg=ubg)
            
            # Check constraint satisfaction
            constraint_value = float(sol['g'])
            print(f"Terminal constraint value: {constraint_value:.6e}")
            
            U_opt = np.array(sol['x']).reshape((self.nb_inputs, N), order='F')
            
            # Store runtime
            step_time = time.time() - step_start
            self.runtimes.append(step_time)
            
            print(f"Step {step_idx+1}: Time={step_time:.3f}s, Horizon={N}, Constraint={constraint_value:.2e}")
            
            # Apply first m steps
            for i in range(self.nb_inputs):
                self.mpc_control[i, t_idx:t_idx+apply_steps] = U_opt[i, :apply_steps]
            
            # Forward simulate for applied steps
            for local in range(apply_steps):
                uk = ca.DM(self.mpc_control[:, t_idx + local])
                self.current_x = np.array(self.step_fun(ca.DM(self.current_x), uk)).reshape(-1)
            
            # Warm start for next iteration
            self.U_prev_window = U_opt.copy()
        
        total_time = time.time() - start_total
        print(f"CasADi MPC completed in {total_time:.2f} seconds")
        print(f"Average step time: {np.mean(self.runtimes):.3f} seconds")
        
        return total_time

def compare_mpc_methods():
    """Compare MPC with and without terminal constraint"""
    # Common parameters
    params = {
        't_end': 5.0,
        'T': 100,
        'L': 30,
        'm': 1,
        'ampl0': 0.2,
        'omega': 1.0
    }
    
    # Run both MPC methods
    results = {}
    
    # MPC without terminal constraint
    print("="*60)
    print("RUNNING MPC WITHOUT TERMINAL CONSTRAINT")
    print("="*60)
    mpc_no_terminal = QuantumMPC_NoTerminal(**params)
    runtime_no_terminal = mpc_no_terminal.run_mpc()
    fidelity_no_terminal = mpc_no_terminal.simulate_final_trajectory()
    results['no_terminal'] = {
        'mpc': mpc_no_terminal,
        'runtime': runtime_no_terminal,
        'fidelity': fidelity_no_terminal
    }
    
    # MPC with terminal constraint
    print("\n" + "="*60)
    print("RUNNING MPC WITH TERMINAL CONSTRAINT")
    print("="*60)
    mpc_terminal = QuantumMPC_Terminal(**params)
    runtime_terminal = mpc_terminal.run_mpc()
    fidelity_terminal = mpc_terminal.simulate_final_trajectory()
    results['terminal'] = {
        'mpc': mpc_terminal,
        'runtime': runtime_terminal,
        'fidelity': fidelity_terminal
    }
    
    # Plot comparison
    plt.figure(figsize=(15, 10))
    
    # Fidelity comparison
    plt.subplot(2, 1, 1)
    plt.plot(results['no_terminal']['mpc'].full_tlist, 
             results['no_terminal']['mpc'].fidelities, 
             label='Basic MPQC',  linewidth=3)
    plt.plot(results['terminal']['mpc'].full_tlist, 
             results['terminal']['mpc'].fidelities, 
             label='TEC MPQC',  linewidth=3)
    plt.axhline(y=1.0, color='r', linestyle='--', label='Target')
    plt.xlabel('Time t', fontsize=20)
    plt.ylabel('Fidelity', fontsize=20)
    plt.title("(a)", fontsize=20, loc = 'left')
    #plt.title('Fidelity Comparison')
    plt.legend(fontsize=20)
    plt.tick_params(axis='both', labelsize=20)
    plt.grid(True)
    
    # Control comparison
    plt.subplot(2, 1, 2)
    plt.plot(results['no_terminal']['mpc'].full_tlist, 
             results['no_terminal']['mpc'].mpc_control[0, :], 
             label='Basic MPQC', linewidth=3)
    plt.plot(results['terminal']['mpc'].full_tlist, 
             results['terminal']['mpc'].mpc_control[0, :], 
             label='TEC MPQC', linewidth=3)
    plt.axhline(y=1.0, color='gray', linestyle='--', alpha=0.7)
    plt.axhline(y=-1.0, color='gray', linestyle='--', alpha=0.7)
    plt.fill_between(results['no_terminal']['mpc'].full_tlist, -1.0, 1.0, color='gray', alpha=0.1)
    plt.xlabel('Time t', fontsize=20)
    plt.ylabel('MPQC input u', fontsize= 20)
    #plt.title('Control Field Comparison')
    plt.title("(b)", fontsize=20, loc = 'left')
    #plt.legend(fontsize=20)
    plt.grid(True, linestyle = '--')
    plt.tick_params(axis='both', labelsize=18)
    plt.ylim(-1.2, 1.2)
    
    # # Population comparison
    # plt.subplot(2, 2, 3)
    # plt.plot(results['no_terminal']['mpc'].full_tlist, 
    #          results['no_terminal']['mpc'].populations[:, 0], 
    #          label='|0⟩ (No Terminal)', linestyle='--')
    # plt.plot(results['no_terminal']['mpc'].full_tlist, 
    #          results['no_terminal']['mpc'].populations[:, 1], 
    #          label='|1⟩ (No Terminal)', linestyle='--')
    # plt.plot(results['terminal']['mpc'].full_tlist, 
    #          results['terminal']['mpc'].populations[:, 0], 
    #          label='|0⟩ (Terminal)', linewidth=2)
    # plt.plot(results['terminal']['mpc'].full_tlist, 
    #          results['terminal']['mpc'].populations[:, 1], 
    #          label='|1⟩ (Terminal)', linewidth=2)
    # plt.xlabel('Time')
    # plt.ylabel('Population')
    # plt.title('Population Comparison')
    # plt.legend()
    # plt.grid(True)
    
    # # Runtime comparison
    # plt.subplot(2, 2, 4)
    # methods = ['No Terminal Constraint', 'With Terminal Constraint']
    # runtimes = [results['no_terminal']['runtime'], results['terminal']['runtime']]
    # fidelities = [results['no_terminal']['fidelity'], results['terminal']['fidelity']]
    
    # bars = plt.bar(methods, runtimes, alpha=0.7)
    # plt.ylabel('Runtime (seconds)')
    # plt.title('Runtime Comparison')
    
    # # Add fidelity values on top of bars
    # for i, (bar, fidelity_val) in enumerate(zip(bars, fidelities)):
    #     plt.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.1, 
    #             f'Fidelity: {fidelity_val:.6f}', ha='center', va='bottom')
    
    # plt.tight_layout()
    # plt.show()
    
    # Print summary
    print("\n" + "="*60)
    print("COMPARISON SUMMARY")
    print("="*60)
    print(f"No Terminal Constraint:")
    print(f"  Final Fidelity: {results['no_terminal']['fidelity']:.9f}")
    print(f"  Total Runtime: {results['no_terminal']['runtime']:.2f} seconds")
    print(f"  Average Step Time: {np.mean(results['no_terminal']['mpc'].runtimes):.3f} seconds")
    
    print(f"\nWith Terminal Constraint:")
    print(f"  Final Fidelity: {results['terminal']['fidelity']:.9f}")
    print(f"  Total Runtime: {results['terminal']['runtime']:.2f} seconds")
    print(f"  Average Step Time: {np.mean(results['terminal']['mpc'].runtimes):.3f} seconds")
    
    # Control energy comparison
    energy_no_terminal = np.sum(results['no_terminal']['mpc'].mpc_control[0, :]**2) * params['t_end']/params['T']
    energy_terminal = np.sum(results['terminal']['mpc'].mpc_control[0, :]**2) * params['t_end']/params['T']
    
    print(f"\nControl Energy:")
    print(f"  No Terminal Constraint: {energy_no_terminal:.4f}")
    print(f"  With Terminal Constraint: {energy_terminal:.4f}")
    
    return results
1
# Run the comparison
if __name__ == "__main__":
    results = compare_mpc_methods()